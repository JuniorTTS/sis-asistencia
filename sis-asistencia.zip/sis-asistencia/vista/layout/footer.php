<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<!-- Popper.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>

<!-- Bootstrap 4 JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<!-- DataTables -->
<script src="../public/app/publico/js/lib/datatables-net/datatables.min.js"></script>

<script>
    // Configuración de DataTables
    $(function() {
        $('#example').DataTable({
            responsive: true,
            "language": {
                "sProcessing": "Procesando...",
                "sLengthMenu": "Mostrar _MENU_ registros",
                "sZeroRecords": "No se encontraron resultados",
                "sEmptyTable": "Ningún dato disponible en esta tabla =(",
                "sInfo": "Registros del _START_ al _END_ de _TOTAL_ registros",
                "sInfoEmpty": "Registros del 0 al 0 de 0 registros",
                "sInfoFiltered": "(filtrado de _MAX_ registros)",
                "sSearch": "Buscar:",
                "oPaginate": {
                    "sFirst": "Primero",
                    "sLast": "Último",
                    "sNext": "Siguiente",
                    "sPrevious": "Anterior"
                }
            }
        });
    });
</script>

<!-- SweetAlert -->
<script src="../public/sweet/js/sweetalert2.js"></script>

<!-- Otros scripts -->
<script src="../public/app/publico/js/lib/jquery-flex-label/jquery.flex.label.js"></script>
<script>
    $(document).ready(function() {
        $('.fl-flex-label').flexLabel();
    });
</script>
