<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de bienvenida</title>
    <link rel="stylesheet" href="public/estilos/estilos.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400&display=swap" rel="stylesheet">
</head>
<body>
<h1>Bienvenido, Regsitra tu asistencia</h1>
<h2 id= "fecha"></h2>
<div class="container">
    <a class="acceso" href="vista/login/login.php">Ingresar al sistema</a>
    <p class="dni">Ingrese su DNI</p>
    <form action="">
        <input type="text" placeholder="DNI del docente" name="txtdni">
<div class="btns">
<a class="entrada" href="">Entrada</a>
<a class="salida" href="">Salida</a>
</div>
    </form>
</div>

<script>
        setInterval(() => {
            let fecha = new Date();
            let fechaStr = fecha.toLocaleDateString();
            let horaStr = fecha.toLocaleTimeString();
            document.getElementById("fecha").textContent = `${fechaStr} ${horaStr}`;
        }, 1000);
    </script>
</body>
</html>