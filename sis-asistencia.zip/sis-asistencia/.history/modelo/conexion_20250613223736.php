<?php
$conexion = new mysqli("localhost", "root", "", "sis_asistencia", 3306);
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}
$conexion->set_charset("utf8");
date_default_timezone_set('America/Asuncion');
?>
