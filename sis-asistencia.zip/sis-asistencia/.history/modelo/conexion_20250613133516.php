<?php

$host = "localhost";
$user = "tu_usuario";
$password = "tu_contraseña";
$db = "tu_basededatos";

$conexion = new mysqli($host, $user, $password, $db);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}
?>
