<?php
$conexion = new mysqli("localhost", "root", "", "sis_asistencia", "3306");
$conexion->set_charset("utf8");
date_default_timezone_set('America/Asuncion');
?>
