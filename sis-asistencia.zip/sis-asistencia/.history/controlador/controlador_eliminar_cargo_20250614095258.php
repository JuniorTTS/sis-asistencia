<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:../login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

// Verificamos que se reciba el ID por GET
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id_cargo = intval($_GET['id']);

    // Preparamos la consulta segura
    $delete = $conexion->prepare("DELETE FROM cargo WHERE id_cargo = ?");
    if ($delete === false) {
        // Si falla la preparación
        header("Location: ../vista/cargo.php?error=Error interno al preparar la consulta");
        exit();
    }

    $delete->bind_param("i", $id_cargo);

    // Ejecutamos la eliminación
    if ($delete->execute()) {
        header("Location: ../vista/cargo.php?mensaje=Cargo eliminado correctamente");
    } else {
        header("Location: ../vista/cargo.php?error=Error al eliminar el cargo");
    }
    exit();
} else {
    header("Location: ../vista/cargo.php?error=ID no válido");
    exit();
}
?>
