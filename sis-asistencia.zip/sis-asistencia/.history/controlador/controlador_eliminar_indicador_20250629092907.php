<?php
session_start();
require_once "../modelo/conexion.php";

if (isset($_GET['id'])) {
    $id_indicador = $_GET['id'];
    
    try {
        $sql = "DELETE FROM indicadores WHERE id_indicador = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("i", $id_indicador);
        
        if ($stmt->execute()) {
            header("Location: ../vista/indicadores.php?mensaje=Indicador eliminado correctamente");
        } else {
            header("Location: ../vista/indicadores.php?error=Error al eliminar el indicador");
        }
    } catch (Exception $e) {
        error_log("Error al eliminar indicador: " . $e->getMessage());
        header("Location: ../vista/indicadores.php?error=Error en el servidor");
    }
} else {
    header("Location: ../vista/indicadores.php");
}
exit();
?>
