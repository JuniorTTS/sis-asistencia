<?php
require_once "../modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_indicador = $_POST['id_indicador'];
    $descripcion = $_POST['descripcion'];
    $fecha = $_POST['fecha'];

    $sql = "UPDATE indicadores SET descripcion = ?, fecha = ? WHERE id_indicador = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("ssi", $descripcion, $fecha, $id_indicador);

    if ($stmt->execute()) {
        header("Location: ../vista/indicadores.php?mensaje=Indicador actualizado correctamente");
    } else {
        header("Location: ../vista/indicadores.php?error=Error al actualizar el indicador");
    }
    $stmt->close();
}
?>
