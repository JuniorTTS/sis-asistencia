<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Verificar si el usuario existe
    $check = $conexion->prepare("SELECT id_usuario FROM usuario WHERE id_usuario = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $res = $check->get_result();

    if ($res->num_rows > 0) {
        // Eliminar usuario
        $del = $conexion->prepare("DELETE FROM usuario WHERE id_usuario = ?");
        $del->bind_param("i", $id);
        if ($del->execute()) {
            header('Location: inicio.php?mensaje=Usuario eliminado correctamente');
            exit();
        } else {
            header('Location: inicio.php?error=Error al eliminar el usuario');
            exit();
        }
    } else {
        header('Location: inicio.php?error=Usuario no encontrado');
        exit();
    }
} else {
    header('Location: inicio.php?error=ID no especificado');
    exit();
}
