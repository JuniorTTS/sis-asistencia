<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:../login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if (isset($_GET['id'])) {
    $id_empleado = intval($_GET['id']);

    if ($id_empleado > 0) {
        // Preparar la consulta para eliminar
        $sql = $conexion->prepare("DELETE FROM empleado WHERE id_empleado = ?");
        $sql->bind_param("i", $id_empleado);

        if ($sql->execute()) {
            $sql->close();
            header("Location: ../vista/empleado.php?mensaje=empleado eliminado correctamente");
            exit();
        } else {
            $sql->close();
            header("Location: ../vista/empleado.php?error=Error al eliminar empleado");
            exit();
        }
    } else {
        header("Location: ../vista/empleado.php?error=ID de empleado no válido");
        exit();
    }
} else {
    header("Location: ../vista/empleado.php?error=ID de empleado no enviado");
    exit();
}
