<?php
session_start();
require_once "../modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_indicador = $_POST['id_indicador'];
    $descripcion = $_POST['descripcion'];

    try {
        $sql = "UPDATE indicadores SET descripcion = ? WHERE id_indicador = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("si", $descripcion, $id_indicador);
        
        if ($stmt->execute()) {
            header("Location: ../vista/indicadores.php?mensaje=Descripción actualizada correctamente");
        } else {
            header("Location: ../vista/indicadores.php?error=Error al actualizar la descripción");
        }
    } catch (Exception $e) {
        error_log("Error al actualizar indicador: " . $e->getMessage());
        header("Location: ../vista/indicadores.php?error=Error en el servidor");
    }
} else {
    header("Location: ../vista/indicadores.php");
}
exit();
?>
