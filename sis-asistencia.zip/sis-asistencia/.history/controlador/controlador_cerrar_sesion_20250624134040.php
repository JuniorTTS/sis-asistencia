<?php
session_start();
session_destroy();
header("Location: /sis-asistencia/vista/login/login.php");
exit();
