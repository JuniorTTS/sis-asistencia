<?php
session_start();
session_destroy();

// DEBUG
echo "Redirigiendo a: /sis-asistencia/vista/login/login.php";
exit;

//header("Location:/sis-asistencia/vista/login/login.php");
//exit();