<?php
session_start();
require_once("../modelo/conexion.php");

if (!empty($_POST["btningresar"])) {
    if (!empty($_POST["usuario"]) && !empty($_POST["password"])) {
        $usuario = $_POST["usuario"];
        $password = md5($_POST["password"]);

        // Asegúrate de que la tabla se llama 'usuario' y tiene la columna 'id_usuario'
        $sql = $conexion->query("SELECT * FROM usuario WHERE usuario='$usuario' AND password='$password'");

        if ($datos = $sql->fetch_object()) {
            $_SESSION["id_usuario"] = $datos->id_usuario;
            $_SESSION["nombre"] = $datos->nombre;
            $_SESSION["apellido"] = $datos->apellido;
            header("location: ../inicio.php");
        } else {
            echo "<div class='alert alert-danger'>El usuario no existe o la contraseña es incorrecta</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Los campos están vacíos</div>";
    }
}
?>
