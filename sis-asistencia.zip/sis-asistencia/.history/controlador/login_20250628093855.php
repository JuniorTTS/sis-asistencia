<?php
session_start();
require_once(__DIR__ . "/../modelo/conexion.php");

if (!empty($_POST["btningresar"])) {
    if (!empty($_POST["usuario"]) && !empty($_POST["password"])) {
        $usuario = $_POST["usuario"];
        $password = $_POST["password"];

        // Consultar en la tabla correcta: usuario
        $sql = $conexion->prepare("SELECT * FROM usuario WHERE usuario = ?");
        $sql->bind_param("s", $usuario);
        $sql->execute();
        $resultado = $sql->get_result();

        if ($resultado->num_rows === 1) {
            $datos = $resultado->fetch_object();

            // Verificar la contraseña con password_verify
            if (password_verify($password, $datos->password)) {
                $_SESSION["nombre"] = $datos->nombre;
                $_SESSION["apellido"] = $datos->apellido;
                $_SESSION["usuario"] = $datos->usuario;
                header("Location: ../inicio.php");
                exit();
            } else {
                echo "<div class='alert alert-danger'>Contraseña incorrecta</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>El usuario no existe</div>";
        }

        $sql->close();
        $conexion->close();
    } else {
        echo "<div class='alert alert-danger'>Los campos están vacíos</div>";
    }
}
?>
