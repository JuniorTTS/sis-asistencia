<?php
require_once "../modelo/conexion.php";

if (!empty($_POST['id'])) {
    $id = $_POST['id'];

    $sql = $conexion->query("DELETE FROM usuario WHERE id_usuario = $id");

    if ($sql) {
        header("Location: ../vista/usuarios.php?mensaje=Usuario eliminado correctamente");
    } else {
        header("Location: ../vista/usuarios.php?error=Error al eliminar usuario");
    }
} else {
    header("Location: ../vista/usuarios.php?error=ID no válido");
}
?>
