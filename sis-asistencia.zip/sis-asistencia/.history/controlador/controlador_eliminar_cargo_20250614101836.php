<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:../login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if (isset($_GET['id'])) {
    $id_cargo = intval($_GET['id']);

    $delete = $conexion->prepare("DELETE FROM cargo WHERE id_cargo=?");
    $delete->bind_param("i", $id_cargo);

    if ($delete->execute()) {
        $_SESSION['mensaje'] = "Cargo eliminado correctamente";
    } else {
        $_SESSION['error'] = "Error al eliminar el cargo";
    }
    header("Location: ../vista/cargo.php");
    exit();
} else {
    $_SESSION['error'] = "ID no válido";
    header("Location: ../vista/cargo.php");
    exit();
}
?>
