<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if (isset($_GET['id'])) {
    $id_empleado = $_GET['id'];

    $delete = $conexion->prepare("DELETE FROM empleado WHERE id_empleado=?");
    $delete->bind_param("i", $id_empleado);

    if ($delete->execute()) {
        header("Location: empleado.php?mensaje=Empleado eliminado correctamente");
    } else {
        header("Location: empleado.php?error=Error al eliminar el empleado");
    }
    exit();
} else {
    header("Location: empleado.php?error=ID no válido");
    exit();
}
?>
