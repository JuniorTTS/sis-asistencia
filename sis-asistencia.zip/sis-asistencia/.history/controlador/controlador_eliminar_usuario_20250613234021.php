<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Verificar que el ID sea válido
    if ($id > 0) {
        // Preparar y ejecutar eliminación
        $stmt = $conexion->prepare("DELETE FROM usuario WHERE id_usuario = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            // Eliminado con éxito
            $stmt->close();
            header("Location: ../vista/usuarios.php?mensaje=Usuario eliminado correctamente");
            exit();
        } else {
            // Error en eliminación
            $stmt->close();
            header("Location: ../vista/usuarios.php?error=Error al eliminar usuario");
            exit();
        }
    } else {
        header("Location: ../vista/usuarios.php?error=ID inválido");
        exit();
    }
} else {
    header("Location: ../vista/usuarios.php?error=ID no especificado");
    exit();
}
?>
