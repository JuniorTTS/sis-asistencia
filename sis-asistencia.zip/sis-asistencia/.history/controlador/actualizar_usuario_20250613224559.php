<?php
// actualizar_usuario.php

session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php"; // tu conexión actual

// Validamos que existan los datos
if (isset($_POST['id_usuario'], $_POST['nombre'], $_POST['apellido'], $_POST['usuario'])) {
    
    // Sanitizamos los datos
    $id_usuario = intval($_POST['id_usuario']);
    $nombre = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $usuario = trim($_POST['usuario']);

    // Preparamos el update
    $sql = "UPDATE usuario SET nombre = ?, apellido = ?, usuario = ? WHERE id_usuario = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("sssi", $nombre, $apellido, $usuario, $id_usuario);

    if ($stmt->execute()) {
        // Redirigimos con mensaje de éxito
        header("Location: usuario.php?mensaje=Usuario actualizado correctamente");
        exit();
    } else {
        // Redirigimos con mensaje de error
        header("Location: usuario.php?error=Error al actualizar el usuario");
        exit();
    }
} else {
    // Datos incompletos
    header("Location: usuario.php?error=Datos incompletos");
    exit();
}
?>
