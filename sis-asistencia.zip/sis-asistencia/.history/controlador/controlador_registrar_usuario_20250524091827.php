<?php

if (!empty($_POST["btnregistrar"])) {
    if (!empty($_POST["txtnombre"]) and !empty($_POST["txtapellido"]) and !empty($_POST["txtusuario"]) and !empty($_POST["txtpassword"])){
        $nombre = $_POST["txtnombre"];
        $apellido = $_POST["txtapellido"];
        $usuario = $_POST["txtusuario"];
        $password = md5($_POST["txtpassword"]);

        $sql=$conexion->query("select count(*) as total from usuarios where usuario='$usuario'");
        if ($sql->fetch_object()->total > 0) {?>
            <script>
                $(function notificacion() {
                    new PNotify({ 
                        title: "ERROR",
                        type: "error",
                        text: "El usuario <?=$usuario ?> ya existe",
                        styling: "bootstrap3",
                    })
                })
            </script>
        <?php } else {
            $registro=$conexion->query("insert into usuarios (nombre, apellido, usuario, password) values ('$nombre', '$apellido', '$usuario', '$password')");
            if ($registro==0) {?>
               <script>
                $(function notificacion() {
                    new PNotify({ 
                        title: "CORRECTO",
                        type: "success",
                        text: "El usuario se registro correctamente",
                        styling: "bootstrap3",
                    })
                })
            </script>
            <?php } else { ?>
             <script>
                $(function notificacion() {
                    new PNotify({ 
                        title: "INCORRECTO",
                        type: "ERROR",
                        text: "Error al registrar el usuario", 
                        styling: "bootstrap3",
                    })
                })
            </script>
            <?php }
            
    }
} else {?>
  <script>
        $(function notificacion() { 
            new PNotify({ 
                title: "ERROR",
                type: "error",
                text: "Los campos no pueden estar vacios",
                styling: "bootstrap3",
            })
        })
    </script>
   <?php }?>
    
<script>
    setTimeout(() => {
       window.history.replaceState(null, null, window.location.pathname); 
    }, timeout=0);
</script>

<?php }
