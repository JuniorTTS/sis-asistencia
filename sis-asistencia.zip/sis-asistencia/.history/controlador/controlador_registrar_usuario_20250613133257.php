<?php
session_start();
require_once("../modelo/conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["btnregistrar"])) {

    // Validación de campos
    if (!empty($_POST["txtnombre"]) && !empty($_POST["txtapellido"]) && 
        !empty($_POST["txtusuario"]) && !empty($_POST["txtpassword"])) {

        $nombre = trim($_POST["txtnombre"]);
        $apellido = trim($_POST["txtapellido"]);
        $usuario = trim($_POST["txtusuario"]);
        $password = trim($_POST["txtpassword"]);
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        // Verificar si el usuario ya existe
        $sql_verificar = "SELECT id FROM usuarios WHERE usuario = ?";
        $stmt = $conexion->prepare($sql_verificar);
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $_SESSION['mensaje'] = '<div class="alert alert-warning">El usuario ya existe.</div>';
        } else {
            $sql_insert = "INSERT INTO usuarios (nombre, apellido, usuario, password) VALUES (?, ?, ?, ?)";
            $stmt_insert = $conexion->prepare($sql_insert);
            $stmt_insert->bind_param("ssss", $nombre, $apellido, $usuario, $passwordHash);

            if ($stmt_insert->execute()) {
                $_SESSION['mensaje'] = '<div class="alert alert-success">Usuario registrado correctamente.</div>';
            } else {
                $_SESSION['mensaje'] = '<div class="alert alert-danger">Error al registrar el usuario.</div>';
            }
            $stmt_insert->close();
        }

        $stmt->close();
        $conexion->close();
    } else {
        $_SESSION['mensaje'] = '<div class="alert alert-warning">Todos los campos son obligatorios.</div>';
    }

    // Redirigimos de vuelta al formulario después de procesar
    header("Location: ../vista/registro_usuario.php");
    exit();
}
?>
