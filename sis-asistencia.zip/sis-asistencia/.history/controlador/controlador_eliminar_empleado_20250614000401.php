<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:../login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if (isset($_GET['id'])) {
    $id_usuario = intval($_GET['id']);

    if ($id_usuario > 0) {
        // Preparar la consulta para eliminar
        $sql = $conexion->prepare("DELETE FROM usuario WHERE id_usuario = ?");
        $sql->bind_param("i", $id_usuario);

        if ($sql->execute()) {
            $sql->close();
            header("Location: ../vista/usuario.php?mensaje=Usuario eliminado correctamente");
            exit();
        } else {
            $sql->close();
            header("Location: ../vista/usuario.php?error=Error al eliminar usuario");
            exit();
        }
    } else {
        header("Location: ../vista/usuario.php?error=ID de usuario no válido");
        exit();
    }
} else {
    header("Location: ../vista/usuario.php?error=ID de usuario no enviado");
    exit();
}
