<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if (isset($_GET['id'])) {
    $id_empleado = intval($_GET['id']); // Asegurar que sea entero

    $delete = $conexion->prepare("DELETE FROM empleado WHERE id_empleado=?");
    $delete->bind_param("i", $id_empleado);

    if ($delete->execute()) {
        // Redirigir a la página lista con mensaje y salir inmediatamente
        header("Location: ../vista/empleado.php?mensaje=Empleado eliminado correctamente");
        exit();
    } else {
        header("Location: ../vista/empleado.php?error=Error al eliminar el empleado");
        exit();
    }
} else {
    header("Location: ../vista/empleado.php?error=ID no válido");
    exit();
}
