<?php
require_once "../modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_usuario = intval($_POST['id_usuario']);
    $nombre = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $usuario = trim($_POST['usuario']);

    if (empty($nombre) || empty($apellido) || empty($usuario)) {
        header("Location: usuarios.php?error=Por favor complete todos los campos.");
        exit();
    }

    $stmt = $conexion->prepare("UPDATE usuario SET nombre = ?, apellido = ?, usuario = ? WHERE id_usuario = ?");
    $stmt->bind_param("sssi", $nombre, $apellido, $usuario, $id_usuario);

    if ($stmt->execute()) {
        header("Location: usuarios.php?mensaje=Usuario actualizado correctamente.");
    } else {
        header("Location: usuarios.php?error=Error al actualizar el usuario.");
    }

    $stmt->close();
    $conexion->close();
} else {
    header("Location: usuarios.php?error=Solicitud inválida.");
}
?>
