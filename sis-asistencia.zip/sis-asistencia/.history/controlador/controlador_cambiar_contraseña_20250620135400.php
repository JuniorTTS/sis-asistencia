<?php
session_start();
require_once "../modelo/conexion.php"; // Ajustá el path si cambia

if (!isset($_SESSION['id_usuario'])) {
    header("Location: ../login/login.php");
    exit();
}

$id_usuario = $_SESSION['id_usuario'];
$contrasena_actual = $_POST['contrasena_actual'];
$nueva_contrasena = $_POST['nueva_contrasena'];

try {
    // Obtener la contraseña actual desde la base de datos
    $stmt = $conexion->prepare("SELECT contrasena FROM usuario WHERE id_usuario = ?");
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $stmt->bind_result($hash_actual);
    $stmt->fetch();
    $stmt->close();

    // Validar la contraseña actual
    if (!password_verify($contrasena_actual, $hash_actual)) {
        header("Location: ../vista/inicio.php?error=Contraseña actual incorrecta");
        exit();
    }

    // Encriptar y actualizar la nueva contraseña
    $nuevo_hash = password_hash($nueva_contrasena, PASSWORD_DEFAULT);
    $stmt = $conexion->prepare("UPDATE usuario SET contrasena = ? WHERE id_usuario = ?");
    $stmt->bind_param("si", $nuevo_hash, $id_usuario);
    $stmt->execute();
    $stmt->close();

    header("Location: ../vista/inicio.php?mensaje=Contraseña actualizada correctamente");
    exit();

} catch (Exception $e) {
    header("Location: ../vista/inicio.php?error=Ocurrió un error");
    exit();
}
