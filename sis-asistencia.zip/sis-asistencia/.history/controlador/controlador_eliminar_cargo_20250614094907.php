<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:../login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if (isset($_GET['id'])) {
    $id_cargo = intval($_GET['id']);

    $delete = $conexion->prepare("DELETE FROM cargo WHERE id_cargo=?");
    $delete->bind_param("i", $id_cargo);

    if ($delete->execute()) {
        header("Location: ../vista/cargo.php?mensaje=Cargo eliminado correctamente");
    } else {
        header("Location: ../vista/cargo.php?error=Error al eliminar el cargo");
    }
    exit();
} else {
    header("Location: ../vista/cargo.php?error=ID no válido");
    exit();
}
?>
