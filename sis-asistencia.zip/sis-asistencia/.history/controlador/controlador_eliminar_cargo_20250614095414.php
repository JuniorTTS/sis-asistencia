<?php
// Iniciamos la sesión
session_start();

// Validamos la sesión activa
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    // Redirigimos al login si no hay sesión
    header('location:../login/login.php');
    exit();
}

// Incluimos la conexión a la base de datos
require_once "../modelo/conexion.php";

// Validamos que el parámetro id venga por GET
if (isset($_GET['id'])) {
    // Sanitizamos el ID recibido
    $id_cargo = intval($_GET['id']);

    // Preparamos la consulta de eliminación
    $delete = $conexion->prepare("DELETE FROM cargo WHERE id_cargo = ?");
    $delete->bind_param("i", $id_cargo);

    // Ejecutamos la eliminación
    if ($delete->execute()) {
        // Redireccionamos correctamente
        header("Location: ../vista/cargo.php?mensaje=Cargo eliminado correctamente");
    } else {
        header("Location: ../vista/cargo.php?error=Error al eliminar el cargo");
    }
    exit();
} else {
    // Si no viene el ID válido
    header("Location: ../vista/cargo.php?error=ID no válido");
    exit();
}
?>
