<?php
session_start();
require('./fpdf/fpdf.php');
require_once "../modelo/conexion.php";

class PDF extends FPDF
{
    function Header()
    {
        $this->SetFont('Arial','B',16);
        $this->SetTextColor(11, 150, 214);
        $this->Cell(0,10,'REPORTE DE ASISTENCIA DEL PERSONAL',0,1,'C');
        $this->Ln(5);

        $this->SetFont('Arial','B',12);
        $this->SetFillColor(11, 150, 214);
        $this->SetTextColor(255,255,255);
        $this->SetX(5); // Centramos la cabecera también
        $this->Cell(10,10,'#',1,0,'C', true);
        $this->Cell(45,10,'Nombre',1,0,'C', true);
        $this->Cell(30,10,'DNI',1,0,'C', true);
        $this->Cell(35,10,'Cargo',1,0,'C', true);
        $this->Cell(40,10,'Entrada',1,0,'C', true);
        $this->Cell(40,10,'Salida',1,1,'C', true);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial','I',10);
        $this->SetTextColor(128);
        $this->Cell(0,10,'Generado el: '.date('d/m/Y H:i').' | Página '.$this->PageNo(),0,0,'C');
    }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial','',11);
$pdf->SetTextColor(0);

$sql = $conexion->query("
    SELECT 
        a.id_asistencia, 
        e.nombre, 
        e.apellido, 
        e.dni, 
        c.nombre AS cargo, 
        a.entrada, 
        a.salida 
    FROM asistencia a
    JOIN empleado e ON a.id_empleado = e.id_empleado
    JOIN cargo c ON e.cargo = c.id_cargo
");

$contador = 1;

while($fila = $sql->fetch_assoc()) {
    $pdf->SetX(5); // Centramos cada fila
    $pdf->Cell(10,10,$contador,1,0,'C');
    $pdf->Cell(45,10,utf8_decode($fila['nombre'].' '.$fila['apellido']),1,0,'C');
    $pdf->Cell(30,10,$fila['dni'],1,0,'C');
    $pdf->Cell(35,10,utf8_decode($fila['cargo']),1,0,'C');
    $pdf->Cell(40,10,$fila['entrada'],1,0,'C');
    $pdf->Cell(40,10,$fila['salida'],1,1,'C');
    $contador++;
}

$pdf->Output();
?>
