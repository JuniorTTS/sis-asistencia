<?php
session_start();
if (empty($_SESSION['id_usuario'])) {
    header('location:../login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";

$mensaje = $_SESSION['mensaje'] ?? '';
unset($_SESSION['mensaje']);

$id_usuario = $_SESSION['id_usuario'];
$nombre = $_SESSION['nombre'];
$apellido = $_SESSION['apellido'];

// Obtener indicadores del usuario
$stmt = $conexion->prepare("SELECT * FROM indicadores WHERE id_usuario = ? ORDER BY fecha DESC");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resultado = $stmt->get_result();
?>

<div class="page-content">
  <h4 class="text-center text-secondary mb-4">Indicadores de <?= htmlspecialchars($nombre . " " . $apellido) ?></h4>

  <?php if ($mensaje): ?>
    <div class="alert alert-success text-center"><?= htmlspecialchars($mensaje) ?></div>
  <?php endif; ?>

  <a href="registro_indicador.php" class="btn btn-success mb-3">
    <i class="fa-solid fa-plus"></i> Nuevo Indicador
  </a>

  <table class="table table-bordered table-hover col-md-8 mx-auto">
    <thead class="table-dark">
      <tr>
        <th>Descripción</th>
        <th>Fecha</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($ind = $resultado->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($ind['descripcion']) ?></td>
          <td><?= htmlspecialchars($ind['fecha']) ?></td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require('./layout/footer.php'); ?>
