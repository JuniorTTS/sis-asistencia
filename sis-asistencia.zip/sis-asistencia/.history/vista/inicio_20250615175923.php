<?php
   session_start();
   if (empty($_SESSION['nombre']) and empty($_SESSION['apellido'])) {
       header('location:login/login.php');
   }
?>

<style>
  ul li:nth-child(1) .activo{
    background: rgb(11, 150, 214) !important;
  }
</style>

<?php require('./layout/topbar.php'); ?>
<?php require('./layout/sidebar.php'); ?>

<div class="page-content">

<h4 class="text-center texte-secondary mb-4">ASISTENCIA DEL PERSONAL</h4>

<!-- Botón para generar el reporte PDF -->
<div class="mb-4 text-end">
  <a href="reporte_asistencia.php" class="btn btn-success" target="_blank">
    <i class="fa-solid fa-file-pdf"></i> Generar Reporte PDF
  </a>
</div>

<?php
include "../modelo/conexion.php";
include "../controlador/controlador_eliminar_asistencia.php";

$sql = $conexion->query("SELECT
	asistencia.id_asistencia, 
	asistencia.id_empleado, 
	asistencia.entrada, 
	asistencia.salida, 
	empleado.nombre as 'nom_docente', 
	empleado.apellido, 
	empleado.dni, 
	cargo.nombre as 'nom_especialidad'
FROM asistencia
	INNER JOIN empleado ON asistencia.id_empleado = empleado.id_empleado
	INNER JOIN cargo ON empleado.cargo = cargo.id_cargo");
?>

<table class="table table-bordered table-hover col-12" id="example">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>PERSONAL</th>
        <th>DNI</th>
        <th>ESPECIALIDAD</th>
        <th>ENTRADA</th>
        <th>SALIDA</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($datos = $sql->fetch_object()) { ?>    
        <tr>
          <td><?= $datos->id_asistencia ?></td>
          <td><?= $datos->nom_docente . " " . $datos->apellido ?></td>
          <td><?= $datos->dni ?></td>
          <td><?= $datos->nom_especialidad ?></td>
          <td><?= $datos->entrada ?></td>
          <td><?= $datos->salida ?></td>
          <td>
            <a href="inicio.php?id=<?= $datos->id_asistencia ?>" onclick="advertencia(event)" class="btn btn-danger">
              <i class="fa-regular fa-trash-can"></i>
            </a>
          </td>
        </tr>
      <?php } ?>
    </tbody>
</table>

</div>
</div>

<?php require('./layout/footer.php'); ?>
