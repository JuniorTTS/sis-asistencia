<?php
session_start();
if (empty($_SESSION['id_usuario']) || empty($_SESSION['nombre']) || empty($_SESSION['apellido'])) {
    header('location:../login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";

$mensaje = $_SESSION['mensaje'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['mensaje'], $_SESSION['error']);

$id_usuario = $_SESSION['id_usuario'];
$nombre = $_SESSION['nombre'];
$apellido = $_SESSION['apellido'];

// Obtener indicadores del usuario logueado
$stmt = $conexion->prepare("SELECT * FROM indicadores WHERE id_usuario = ? ORDER BY fecha DESC");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$resultado = $stmt->get_result();
?>

<style>
  ul li:nth-child(5) .activo {
    background: rgb(11, 150, 214) !important;
  }

  .modal-custom {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }

  .modal-content-custom {
    background: #fff;
    padding: 30px 20px;
    width: 400px;
    border-radius: 12px;
    position: relative;
    box-shadow: 0 8px 16px rgba(0,0,0,0.2);
    animation: fadeIn 0.3s ease-in-out;
  }

  .close-custom {
    position: absolute;
    right: 15px;
    top: 10px;
    font-size: 24px;
    cursor: pointer;
    color: #999;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: scale(0.95); }
    to { opacity: 1; transform: scale(1); }
  }
</style>

<!-- DataTables CSS y JS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<div class="page-content">
  <h4 class="text-center text-secondary mb-4">Indicadores de <?= htmlspecialchars($nombre . ' ' . $apellido) ?></h4>

  <?php if ($mensaje): ?>
    <div id="alerta-mensaje" class="alert alert-success text-center"><?= htmlspecialchars($mensaje) ?></div>
  <?php endif; ?>

  <?php if ($error): ?>
    <div id="alerta-mensaje" class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <a href="registro_indicador.php" class="btn btn-primary btn-rounded mb-3">
    <i class="fa-solid fa-plus"></i> Registrar Indicador
  </a>

  <table id="tabla-indicadores" class="table table-bordered table-hover col-md-8 mx-auto">
    <thead class="table-dark">
      <tr>
        <th>Descripción</th>
        <th>Fecha</th>
        <th style="width: 150px;" class="text-center">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($ind = $resultado->fetch_object()): ?>
        <tr>
          <td><?= htmlspecialchars($ind->descripcion) ?></td>
          <td><?= htmlspecialchars($ind->fecha) ?></td>
          <td class="text-center">
            <button class="btn btn-warning btn-edit" 
                    data-id="<?= $ind->id_indicador ?>" 
                    data-descripcion="<?= htmlspecialchars($ind->descripcion) ?>" 
                    title="Modificar">
              <i class="fa-solid fa-pen"></i>
            </button>
            <button class="btn btn-danger btn-eliminar" 
                    data-id="<?= $ind->id_indicador ?>" 
                    title="Eliminar">
              <i class="fa-regular fa-trash-can"></i>
            </button>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- Modal de editar -->
<div id="editarModal" class="modal-custom" tabindex="-1" role="dialog" aria-modal="true" aria-labelledby="editarModalLabel">
  <div class="modal-content-custom">
    <button type="button" class="close-custom" aria-label="Cerrar" id="closeEditarModal">&times;</button>
    <form action="../controlador/actualizar_indicador.php" method="POST">
      <input type="hidden" id="modal-id" name="id_indicador">
      <div class="form-group">
        <label for="modal-descripcion">Descripción</label>
        <textarea id="modal-descripcion" name="descripcion" class="form-control" required></textarea>
      </div>
      <button type="submit" class="btn btn-primary mt-3">Guardar Cambios</button>
    </form>
  </div>
</div>

<!-- Modal de Confirmación de Eliminación -->
<div id="confirmarEliminarModal" class="modal-custom" tabindex="-1" role="dialog" aria-modal="true" aria-labelledby="confirmarEliminarLabel">
  <div class="modal-content-custom text-center">
    <button type="button" class="close-custom" aria-label="Cerrar" id="closeConfirmModal">&times;</button>
    <h5 id="confirmarEliminarLabel" class="mb-3">Confirmar Eliminación</h5>
    <p>¿Estás seguro de que deseas eliminar este indicador?</p>
    <div class="d-flex justify-content-center mt-4">
      <button id="cancelarEliminar" class="btn btn-secondary mx-2">Cancelar</button>
      <button id="confirmarEliminarBtn" class="btn btn-danger mx-2">Eliminar</button>
    </div>
  </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
  $(document).ready(function() {
    // Inicializar DataTable con buscador y paginación
    $('#tabla-indicadores').DataTable({
      "language": {
        "search": "Buscar:",
        "lengthMenu": "Mostrar _MENU_ registros",
        "zeroRecords": "No se encontraron resultados",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
        "infoEmpty": "Mostrando 0 a 0 de 0 registros",
        "infoFiltered": "(filtrado de _MAX_ registros totales)",
        "paginate": {
          "first":      "Primero",
          "last":       "Último",
          "next":       "Siguiente",
          "previous":   "Anterior"
        },
      }
    });

    // Variables modales
    const editarModal = document.getElementById('editarModal');
    const confirmarEliminarModal = document.getElementById('confirmarEliminarModal');
    let eliminarUrl = "";

    // Abrir modal editar y rellenar campos
    $('.btn-edit').click(function() {
      const id = $(this).data('id');
      const descripcion = $(this).data('descripcion');

      $('#modal-id').val(id);
      $('#modal-descripcion').val(descripcion);
      editarModal.style.display = 'flex';
    });

    // Cerrar modal editar
    $('#closeEditarModal').click(function() {
      editarModal.style.display = 'none';
    });

    // Cerrar modal eliminar
    $('#closeConfirmModal, #cancelarEliminar').click(function() {
      confirmarEliminarModal.style.display = 'none';
    });

    // Confirmar eliminación: abrir modal y setear URL
    $('.btn-eliminar').click(function() {
      const id = $(this).data('id');
      eliminarUrl = "../controlador/controlador_eliminar_indicador.php?id=" + id;
      confirmarEliminarModal.style.display = 'flex';
    });

    // Botón confirmar eliminar: redirigir
    $('#confirmarEliminarBtn').click(function() {
      window.location.href = eliminarUrl;
    });

    // Cerrar modales si se hace clic fuera del contenido
    window.addEventListener('click', (e) => {
      if (e.target === editarModal) {
        editarModal.style.display = 'none';
      }
      if (e.target === confirmarEliminarModal) {
        confirmarEliminarModal.style.display = 'none';
      }
    });

    // Ocultar mensajes después de 3 segundos y limpiar URL
    setTimeout(() => {
      const alerta = document.getElementById('alerta-mensaje');
      if (alerta) {
        alerta.style.transition = "opacity 0.5s ease";
        alerta.style.opacity = 0;
        setTimeout(() => {
          alerta.remove();
        }, 500);
      }

      if (window.history.replaceState) {
        const url = new URL(window.location);
        url.searchParams.delete('mensaje');
        url.searchParams.delete('error');
        window.history.replaceState({}, document.title, url.pathname);
      }
    }, 3000);
  });
</script>
