<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
require_once "../controlador/controlador_eliminar_asistencia.php";
?>

<style>
  ul li:nth-child(2) .activo {
    background: rgb(11, 150, 214) !important;
  }
</style>

<div class="page-content">
  <h4 class="text-center texte-secondary">LISTA DE USUARIOS </h4>

  <!-- Mostrar mensajes -->
  <?php if (isset($_GET['mensaje'])): ?>
    <div class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
  <?php elseif (isset($_GET['error'])): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
  <?php endif; ?>

  <a href="registro_usuario.php" class="btn btn-primary btn-rounded mb-2">
    <i class="fa-solid fa-plus"></i> Registrar
  </a>

  <table class="table table-bordered table-hover col-md-12" id="example">
    <thead>
      <tr>
        <th>ID</th>
        <th>NOMBRE</th>
        <th>APELLIDO</th>
        <th>USUARIO</th>
        <th>ACCIONES</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = $conexion->query("SELECT * FROM usuario");
      while ($datos = $sql->fetch_object()):
      ?>
        <tr>
          <td><?= $datos->id_usuario ?></td>
          <td><?= htmlspecialchars($datos->nombre) ?></td>
          <td><?= htmlspecialchars($datos->apellido) ?></td>
          <td><?= htmlspecialchars($datos->usuario) ?></td>
          <td>
            <a href="#" data-toggle="modal" data-target="#editarModal<?= $datos->id_usuario ?>" class="btn btn-warning btn-sb">
              <i class="fa-solid fa-user-pen"></i>
            </a>
            <a href="inicio.php?id=<?= $datos->id_usuario ?>" onclick="advertencia(event)" class="btn btn-danger">
              <i class="fa-regular fa-trash-can"></i>
            </a>
          </td>
        </tr>

        <!-- Modal -->
        <div class="modal fade" id="editarModal<?= $datos->id_usuario ?>" tabindex="-1" aria-labelledby="modalLabel<?= $datos->id_usuario ?>" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <form action="actualizar_usuario.php" method="POST">
                <div class="modal-header">
                  <h5 class="modal-title" id="modalLabel<?= $datos->id_usuario ?>">Editar Usuario</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>

                <div class="modal-body">
                  <input type="hidden" name="id_usuario" value="<?= $datos->id_usuario ?>">
                  <div class="form-group">
                    <label>Nombre</label>
                    <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($datos->nombre) ?>" required>
                  </div>
                  <div class="form-group">
                    <label>Apellido</label>
                    <input type="text" name="apellido" class="form-control" value="<?= htmlspecialchars($datos->apellido) ?>" required>
                  </div>
                  <div class="form-group">
                    <label>Usuario</label>
                    <input type="text" name="usuario" class="form-control" value="<?= htmlspecialchars($datos->usuario) ?>" required>
                  </div>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                  <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                </div>
              </form>
            </div>
          </div>
        </div>

      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require('./layout/footer.php'); ?>
