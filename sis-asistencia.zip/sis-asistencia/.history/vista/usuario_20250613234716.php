<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php"; // Aquí la conexión a BD
?>

<style>
  ul li:nth-child(2) .activo {
    background: rgb(11, 150, 214) !important;
  }
  /* Modal personalizado */
  .modal-custom {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }
  .modal-content-custom {
    background: #fff;
    padding: 20px;
    width: 400px;
    border-radius: 8px;
    position: relative;
  }
  .close-custom {
    position: absolute;
    right: 10px;
    top: 10px;
    font-size: 24px;
    cursor: pointer;
  }
</style>

<div class="page-content">
  <h4 class="text-center texte-secondary">LISTA DE USUARIOS </h4>

  <!-- Mostrar mensajes -->
  <?php if (isset($_GET['mensaje'])): ?>
    <div class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
  <?php elseif (isset($_GET['error'])): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
  <?php endif; ?>

  <a href="registro_usuario.php" class="btn btn-primary btn-rounded mb-2">
    <i class="fa-solid fa-plus"></i> Registrar
  </a>

  <table class="table table-bordered table-hover col-md-12" id="example">
    <thead>
      <tr>
        <th>ID</th>
        <th>NOMBRE</th>
        <th>APELLIDO</th>
        <th>USUARIO</th>
        <th>ACCIONES</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = $conexion->query("SELECT * FROM usuario");
      while ($datos = $sql->fetch_object()):
      ?>
        <tr>
          <td><?= $datos->id_usuario ?></td>
          <td><?= htmlspecialchars($datos->nombre) ?></td>
          <td><?= htmlspecialchars($datos->apellido) ?></td>
          <td><?= htmlspecialchars($datos->usuario) ?></td>
          <td>
            <button class="btn btn-warning btn-edit" 
                    data-id="<?= $datos->id_usuario ?>" 
                    data-nombre="<?= htmlspecialchars($datos->nombre) ?>" 
                    data-apellido="<?= htmlspecialchars($datos->apellido) ?>" 
                    data-usuario="<?= htmlspecialchars($datos->usuario) ?>">
              <i class="fa-solid fa-user-pen"></i>
            </button>

            <!-- Aquí el enlace para eliminar -->
            <a href="controlador/controlador_eliminar_usuario.php?id=<?= $datos->id_usuario ?>" onclick="return confirmarEliminar();" class="btn btn-danger">
              <i class="fa-regular fa-trash-can"></i>
            </a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- Modal único reutilizable -->
<div id="editarModal" class="modal-custom">
  <div class="modal-content-custom">
    <span class="close-custom">&times;</span>
    <form action="actualizar_usuario.php" method="POST">
      <input type="hidden" id="modal-id" name="id_usuario">
      <div class="form-group">
        <label>Nombre</label>
        <input type="text" id="modal-nombre" name="nombre" class="form-control" required>
      </div>
      <div class="form-group">
        <label>Apellido</label>
        <input type="text" id="modal-apellido" name="apellido" class="form-control" required>
      </div>
      <div class="form-group">
        <label>Usuario</label>
        <input type="text" id="modal-usuario" name="usuario" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary mt-2">Guardar Cambios</button>
    </form>
  </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
// Control modal editar
document.querySelectorAll('.btn-edit').forEach(button => {
  button.addEventListener('click', () => {
    document.getElementById('modal-id').value = button.dataset.id;
    document.getElementById('modal-nombre').value = button.dataset.nombre;
    document.getElementById('modal-apellido').value = button.dataset.apellido;
    document.getElementById('modal-usuario').value = button.dataset.usuario;
    document.getElementById('editarModal').style.display = 'flex';
  });
});

document.querySelector('.close-custom').addEventListener('click', () => {
  document.getElementById('editarModal').style.display = 'none';
});

// Confirmar eliminación
function confirmarEliminar() {
  return confirm('¿Está seguro que desea eliminar este usuario?');
}
</script>
