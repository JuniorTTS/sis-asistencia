<?php
// Incluimos la conexión
require_once "../modelo/conexion.php";

// Verificamos si se recibió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Validamos que todos los campos vengan completos
    if (!empty($_POST['id_usuario']) && !empty($_POST['nombre']) && !empty($_POST['apellido']) && !empty($_POST['usuario'])) {

        // Sanitizamos los datos
        $id_usuario = intval($_POST['id_usuario']);
        $nombre = trim($_POST['nombre']);
        $apellido = trim($_POST['apellido']);
        $usuario = trim($_POST['usuario']);

        // Preparamos el UPDATE
        $stmt = $conexion->prepare("UPDATE usuario SET nombre = ?, apellido = ?, usuario = ? WHERE id_usuario = ?");
        $stmt->bind_param("sssi", $nombre, $apellido, $usuario, $id_usuario);

        // Ejecutamos y verificamos
        if ($stmt->execute()) {
            $stmt->close();
            // Redireccionamos al volver
            header("Location: lista_usuarios.php?mensaje=Usuario actualizado correctamente");
            exit();
        } else {
            $stmt->close();
            header("Location: lista_usuarios.php?error=Error al actualizar el usuario");
            exit();
        }

    } else {
        header("Location: lista_usuarios.php?error=Faltan datos");
        exit();
    }

} else {
    header("Location: lista_usuarios.php");
    exit();
}
?>
