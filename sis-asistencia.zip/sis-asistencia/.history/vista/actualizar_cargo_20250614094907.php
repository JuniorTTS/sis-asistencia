<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";

if (!isset($_GET['id'])) {
    header("Location: cargo.php?error=ID no válido");
    exit();
}

$id_cargo = intval($_GET['id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);

    $update = $conexion->prepare("UPDATE cargo SET nombre=? WHERE id_cargo=?");
    $update->bind_param("si", $nombre, $id_cargo);

    if ($update->execute()) {
        header("Location: cargo.php?mensaje=Cargo actualizado correctamente");
        exit();
    } else {
        header("Location: cargo.php?error=Error al actualizar el cargo");
        exit();
    }
}

$resultado = $conexion->prepare("SELECT nombre FROM cargo WHERE id_cargo=?");
$resultado->bind_param("i", $id_cargo);
$resultado->execute();
$resultado->bind_result($nombre);
$resultado->fetch();
$resultado->close();
?>

<div class="page-content">
    <h4 class="text-center texte-secondary">Editar Cargo</h4>

    <form method="POST">
        <div class="form-group">
            <label>Nombre del Cargo</label>
            <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($nombre) ?>" required>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Guardar Cambios</button>
        <a href="cargo.php" class="btn btn-secondary mt-3">Volver</a>
    </form>
</div>

<?php require('./layout/footer.php'); ?>
