<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
?>

<div class="page-content">
    <h4 class="text-center texte-secondary">LISTA DE CARGOS</h4>

    <?php if (isset($_GET['mensaje'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
    <?php elseif (isset($_GET['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
    <?php endif; ?>

    <a href="registro_cargo.php" class="btn btn-primary btn-rounded mb-2">
        <i class="fa-solid fa-plus"></i> Registrar
    </a>

    <table class="table table-bordered table-hover col-md-12" id="example">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre del Cargo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = $conexion->query("SELECT * FROM cargo ORDER BY nombre ASC");
            while ($datos = $sql->fetch_object()):
            ?>
                <tr>
                    <td><?= $datos->id_cargo ?></td>
                    <td><?= htmlspecialchars($datos->nombre) ?></td>
                    <td>
                        <button class="btn btn-warning btn-edit"
                                data-id="<?= $datos->id_cargo ?>"
                                data-nombre="<?= htmlspecialchars($datos->nombre) ?>">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>
                        <a href="../controlador/controlador_eliminar_cargo.php?id=<?= $datos->id_cargo ?>"
                           onclick="return confirm('¿Está seguro de eliminar este cargo?');"
                           class="btn btn-danger">
                            <i class="fa-regular fa-trash-can"></i>
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Modal para editar cargo -->
<div id="editarModal" class="modal-custom" style="display:none;">
  <div class="modal-content-custom">
    <span class="close-custom">&times;</span>
    <form action="actualizar_cargo.php" method="POST">
      <input type="hidden" id="modal-id" name="id_cargo">
      <div class="form-group">
        <label>Nombre del Cargo</label>
        <input type="text" id="modal-nombre" name="nombre" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary mt-2">Guardar Cambios</button>
    </form>
  </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
// Modal editar
document.querySelectorAll('.btn-edit').forEach(button => {
  button.addEventListener('click', () => {
    document.getElementById('modal-id').value = button.dataset.id;
    document.getElementById('modal-nombre').value = button.dataset.nombre;
    document.getElementById('editarModal').style.display = 'flex';
  });
});
document.querySelector('.close-custom').addEventListener('click', () => {
  document.getElementById('editarModal').style.display = 'none';
});
</script>
