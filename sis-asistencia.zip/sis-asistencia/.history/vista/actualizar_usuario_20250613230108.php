<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php"; // Ajusta la ruta según tu estructura

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validar que los datos existan
    if (!empty($_POST['id_usuario']) && !empty($_POST['nombre']) && !empty($_POST['apellido']) && !empty($_POST['usuario'])) {
        $id_usuario = intval($_POST['id_usuario']);
        $nombre = trim($_POST['nombre']);
        $apellido = trim($_POST['apellido']);
        $usuario = trim($_POST['usuario']);

        // Preparar la consulta para actualizar usuario
        $sql = "UPDATE usuario SET nombre = ?, apellido = ?, usuario = ? WHERE id_usuario = ?";
        $stmt = $conexion->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("sssi", $nombre, $apellido, $usuario, $id_usuario);
            if ($stmt->execute()) {
                $stmt->close();
                $conexion->close();
                // Redirigir con mensaje de éxito
                header("Location: lista_usuarios.php?mensaje=Usuario actualizado correctamente");
                exit();
            } else {
                $error = "Error al actualizar el usuario.";
            }
        } else {
            $error = "Error en la preparación de la consulta.";
        }
    } else {
        $error = "Todos los campos son obligatorios.";
    }
} else {
    $error = "Método no permitido.";
}

// Si hay error, mostrarlo y opción para volver
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Error al actualizar usuario</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <div class="alert alert-danger">
        <?= htmlspecialchars($error) ?>
    </div>
    <a href="lista_usuarios.php" class="btn btn-primary">Volver a la lista</a>
</body>
</html>
