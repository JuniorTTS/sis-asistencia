<?php
session_start();
require_once "../modelo/conexion.php";

// Verificar que llegan los datos
if (isset($_POST['nombre'], $_POST['telefono'], $_POST['ubicacion'], $_POST['correo'])) {
    $nombre = trim($_POST['nombre']);
    $telefono = trim($_POST['telefono']);
    $ubicacion = trim($_POST['ubicacion']);
    $correo = trim($_POST['correo']);

    // Validar correo básico
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = "Correo electrónico inválido.";
        header("Location: acerca_de.php");
        exit();
    }

    // Actualizamos los datos de la empresa (solo hay una, por eso no usamos WHERE)
    $sql = "UPDATE empresa SET nombre=?, telefono=?, ubicacion=?, correo=? LIMIT 1";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("ssss", $nombre, $telefono, $ubicacion, $correo);

    if ($stmt->execute()) {
        $_SESSION['mensaje'] = "Datos de la empresa actualizados correctamente.";
    } else {
        $_SESSION['error'] = "Error al actualizar los datos.";
    }

    $stmt->close();
} else {
    $_SESSION['error'] = "Todos los campos son obligatorios.";
}

header("Location: acerca_de.php");
exit();
?>
