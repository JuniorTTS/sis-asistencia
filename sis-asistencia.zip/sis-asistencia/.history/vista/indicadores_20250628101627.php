<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
require_once "../controlador/controlador_eliminar_asistencia.php";
?>

<style>
  ul li:nth-child(3) .activo {
    background: rgb(11, 150, 214) !important;
  }

  .modal-custom {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }

  .modal-content-custom {
    background: #fff;
    padding: 30px 20px;
    width: 400px;
    border-radius: 12px;
    position: relative;
    box-shadow: 0 8px 16px rgba(0,0,0,0.2);
    animation: fadeIn 0.3s ease-in-out;
  }

  .close-custom {
    position: absolute;
    right: 15px;
    top: 10px;
    font-size: 24px;
    cursor: pointer;
    color: #999;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: scale(0.95); }
    to { opacity: 1; transform: scale(1); }
  }
</style>

<div class="page-content">
  <h4 class="text-center texte-secondary">INDICADORES</h4>

  <?php if (isset($_GET['mensaje'])): ?>
    <div id="alerta-mensaje" class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
  <?php elseif (isset($_GET['error'])): ?>
    <div id="alerta-mensaje" class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
  <?php endif; ?>

  <a href="registro_empleado.php" class="btn btn-primary btn-rounded mb-2">
    <i class="fa-solid fa-plus"></i> Registrar 
  </a>

  <table class="table table-bordered table-hover col-md-12" id="example">
    <thead>
      <tr>
        <th>ID</th>
        <th>NOMBRE</th>
        <th>APELLIDO</th>
        <th>DNI</th>
        <th>CARGO</th>
        <th>ACCIONES</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = $conexion->query("SELECT
        empleado.id_empleado, 
        empleado.nombre, 
        empleado.apellido, 
        empleado.dni, 
        empleado.cargo, 
        cargo.nombre as nom_cargo
      FROM
        empleado
        INNER JOIN cargo ON empleado.cargo = cargo.id_cargo");
      while ($datos = $sql->fetch_object()):
      ?>
        <tr>
          <td><?= $datos->id_empleado ?></td>
          <td><?= htmlspecialchars($datos->nombre) ?></td>
          <td><?= htmlspecialchars($datos->apellido) ?></td>
          <td><?= htmlspecialchars($datos->dni) ?></td>
          <td><?= htmlspecialchars($datos->nom_cargo) ?></td>
          <td>
            <button class="btn btn-warning btn-edit" 
                    data-id="<?= $datos->id_empleado ?>" 
                    data-nombre="<?= htmlspecialchars($datos->nombre) ?>" 
                    data-apellido="<?= htmlspecialchars($datos->apellido) ?>" 
                    data-dni="<?= htmlspecialchars($datos->dni) ?>" 
                    data-cargo="<?= $datos->cargo ?>">
              <i class="fa-solid fa-user-pen"></i>
            </button>

            <a href="../controlador/controlador_eliminar_empleado.php?id=<?= $datos->id_empleado ?>"
               onclick="confirmarEliminar(event, this.href)" 
               class="btn btn-danger">
              <i class="fa-regular fa-trash-can"></i>
            </a>

          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- Modal de editar -->
<div id="editarModal" class="modal-custom" tabindex="-1" role="dialog" aria-modal="true" aria-labelledby="editarModalLabel">
  <div class="modal-content-custom">
    <button type="button" class="close-custom" aria-label="Cerrar" id="closeEditarModal">&times;</button>
    <form action="actualizar_empleado.php" method="POST">
      <input type="hidden" id="modal-id" name="id_empleado">
      <div class="form-group">
        <label for="modal-nombre">Nombre</label>
        <input type="text" id="modal-nombre" name="nombre" class="form-control" required>
      </div>
      <div class="form-group">
        <label for="modal-apellido">Apellido</label>
        <input type="text" id="modal-apellido" name="apellido" class="form-control" required>
      </div>
      <div class="form-group">
        <label for="modal-dni">DNI</label>
        <input type="text" id="modal-dni" name="dni" class="form-control" required>
      </div>
      <div class="form-group">
        <label for="modal-cargo">Cargo</label>
        <select id="modal-cargo" name="cargo" class="form-control" required>
          <option value="">Seleccione un cargo</option>
          <?php
            $cargos = $conexion->query("SELECT id_cargo, nombre FROM cargo ORDER BY nombre ASC");
            while($cargo = $cargos->fetch_object()):
          ?>
            <option value="<?= $cargo->id_cargo ?>"><?= htmlspecialchars($cargo->nombre) ?></option>
          <?php endwhile; ?>
        </select>
      </div>
      <button type="submit" class="btn btn-primary mt-2">Guardar Cambios</button>
    </form>
  </div>
</div>

<!-- Modal de Confirmación de Eliminación -->
<div id="confirmarEliminarModal" class="modal-custom" tabindex="-1" role="dialog" aria-modal="true" aria-labelledby="confirmarEliminarLabel">
  <div class="modal-content-custom text-center">
    <button type="button" class="close-custom" aria-label="Cerrar" id="closeConfirmModal">&times;</button>
    <h5 id="confirmarEliminarLabel" class="mb-3">Confirmar Eliminación</h5>
    <p>¿Estás seguro de que deseas eliminar este empleado?</p>
    <div class="d-flex justify-content-center mt-4">
      <button id="cancelarEliminar" class="btn btn-secondary mx-2">Cancelar</button>
      <button id="confirmarEliminarBtn" class="btn btn-danger mx-2">Eliminar</button>
    </div>
  </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
// Variables modales
const editarModal = document.getElementById('editarModal');
const confirmarEliminarModal = document.getElementById('confirmarEliminarModal');
let eliminarUrl = "";

// Abrir modal editar y rellenar campos
document.querySelectorAll('.btn-edit').forEach(button => {
  button.addEventListener('click', () => {
    document.getElementById('modal-id').value = button.dataset.id;
    document.getElementById('modal-nombre').value = button.dataset.nombre;
    document.getElementById('modal-apellido').value = button.dataset.apellido;
    document.getElementById('modal-dni').value = button.dataset.dni;
    document.getElementById('modal-cargo').value = button.dataset.cargo;
    editarModal.style.display = 'flex';
  });
});

// Cerrar modal editar
document.getElementById('closeEditarModal').addEventListener('click', () => {
  editarModal.style.display = 'none';
});

// Cerrar modal eliminar
document.getElementById('closeConfirmModal').addEventListener('click', () => {
  confirmarEliminarModal.style.display = 'none';
});

document.getElementById('cancelarEliminar').addEventListener('click', () => {
  confirmarEliminarModal.style.display = 'none';
});

// Confirmar eliminación
function confirmarEliminar(event, url) {
  event.preventDefault();
  eliminarUrl = url;
  confirmarEliminarModal.style.display = 'flex';
}

document.getElementById('confirmarEliminarBtn').addEventListener('click', () => {
  window.location.href = eliminarUrl;
});

// Cerrar modales si se hace clic fuera del contenido
window.addEventListener('click', (e) => {
  if (e.target === editarModal) {
    editarModal.style.display = 'none';
  }
  if (e.target === confirmarEliminarModal) {
    confirmarEliminarModal.style.display = 'none';
  }
});

// Ocultar el mensaje después de 3 segundos y limpiar la URL
setTimeout(() => {
  const alerta = document.getElementById('alerta-mensaje');
  if (alerta) {
    alerta.style.transition = "opacity 0.5s ease";
    alerta.style.opacity = 0;
    setTimeout(() => {
      alerta.remove();
    }, 500);
  }

  if (window.history.replaceState) {
    const url = new URL(window.location);
    url.searchParams.delete('mensaje');
    url.searchParams.delete('error');
    window.history.replaceState({}, document.title, url.pathname);
  }
}, 3000);
</script>
