<?php
session_start();
if (empty($_SESSION['nombre']) and empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit;
}

// Aquí asumo que tienes una conexión a la base de datos en $conn
require_once '../config/conexion.php';

// Consultar cargos
$sql = "SELECT * FROM cargo ORDER BY id_cargo ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Gestión de Cargos</title>

<!-- Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- FontAwesome 6 -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css">

<style>
  /* Para que los botones tengan espacio */
  .btn {
    margin-right: 5px;
  }
</style>
</head>
<body>
<div class="container mt-4">

  <h2 class="mb-4">Listado de Cargos</h2>

  <a href="./registrar_cargo.php" class="btn btn-primary btn-rounded mb-3">
    <i class="fa-solid fa-plus"></i> Nuevo Cargo
  </a>

  <table class="table table-striped table-bordered" id="tabla-cargos" style="width:100%">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($cargo = $result->fetch_object()): ?>
      <tr>
        <td><?= $cargo->id_cargo ?></td>
        <td><?= htmlspecialchars($cargo->nombre) ?></td>
        <td>
          <a href="editar_cargo.php?id=<?= $cargo->id_cargo ?>" class="btn btn-warning btn-sm" title="Editar">
            <i class="fa-solid fa-pen-to-square"></i>
          </a>
          <a href="eliminar_cargo.php?id=<?= $cargo->id_cargo ?>" class="btn btn-danger btn-sm" title="Eliminar" onclick="return confirm('¿Seguro que desea eliminar este cargo?');">
            <i class="fa-solid fa-trash"></i>
          </a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>

<script>
$(document).ready(function() {
    $('#tabla-cargos').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.5/i18n/es-ES.json'
        },
        paging: true,
        searching: true,
        ordering:  true,
        info: true,
        lengthChange: false,
        pageLength: 5
    });
});
</script>
</body>
</html>
