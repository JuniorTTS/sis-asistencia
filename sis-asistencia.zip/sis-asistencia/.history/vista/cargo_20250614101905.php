<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

// Obtener mensajes flash
$mensaje = $_SESSION['mensaje'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['mensaje'], $_SESSION['error']);

// Obtener lista de cargos
$resultado = $conexion->query("SELECT * FROM cargo ORDER BY nombre ASC");
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <title>Cargos</title>
    <link href="../public/bootstrap5/css/bootstrap.min.css" rel="stylesheet">
    <style>
        ul li:nth-child(4) .activo {
            background: rgb(11, 150, 214) !important;
        }

        .modal-custom {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.6);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }

        .modal-content-custom {
            background: #fff;
            padding: 30px 20px;
            width: 400px;
            border-radius: 12px;
            position: relative;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            animation: fadeIn 0.3s ease-in-out;
        }

        .close-custom {
            position: absolute;
            right: 15px;
            top: 10px;
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }
    </style>
</head>

<body class="with-side-menu">
    <?php require('./layout/topbar.php'); ?>
    <?php require('./layout/sidebar.php'); ?>

    <div class="page-content">
        <h4 class="text-center text-secondary">Lista de Cargos</h4>

        <?php if ($mensaje): ?>
            <div class="alert alert-success text-center" role="alert"><?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger text-center" role="alert"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="text-end mb-3">
            <a href="registrar_cargo.php" class="btn btn-primary">Nuevo Cargo</a>
        </div>

        <table class="table table-striped table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($cargo = $resultado->fetch_object()): ?>
                    <tr>
                        <td><?= htmlspecialchars($cargo->nombre) ?></td>
                        <td>
                            <a href="actualizar_cargo.php?id=<?= $cargo->id_cargo ?>" class="btn btn-warning btn-sm">Modificar</a>
                            <button class="btn btn-danger btn-sm btn-eliminar" data-id="<?= $cargo->id_cargo ?>">Eliminar</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Modal eliminar -->
    <div id="modalEliminar" class="modal-custom">
        <div class="modal-content-custom">
            <span class="close-custom" id="cerrarModal">&times;</span>
            <h5>¿Está seguro de eliminar este cargo?</h5>
            <form id="formEliminar" method="GET" action="../controlador/controlador_eliminar_cargo.php">
                <input type="hidden" name="id" id="idEliminar">
                <button type="submit" class="btn btn-danger mt-3">Eliminar</button>
                <button type="button" class="btn btn-secondary mt-3" id="cancelarEliminar">Cancelar</button>
            </form>
        </div>
    </div>

    <script>
        // Variables modal
        const modal = document.getElementById('modalEliminar');
        const btnCerrar = document.getElementById('cerrarModal');
        const btnCancelar = document.getElementById('cancelarEliminar');
        const inputIdEliminar = document.getElementById('idEliminar');

        // Mostrar modal al hacer click en eliminar
        document.querySelectorAll('.btn-eliminar').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.getAttribute('data-id');
                inputIdEliminar.value = id;
                modal.style.display = 'flex';
            });
        });

        // Cerrar modal
        btnCerrar.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        btnCancelar.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        // Cerrar modal si clic afuera
        window.addEventListener('click', (e) => {
            if (e.target == modal) {
                modal.style.display = 'none';
            }
        });

        // Ocultar mensajes luego de 3 segundos
        setTimeout(() => {
            const alertSuccess = document.querySelector('.alert-success');
            const alertError = document.querySelector('.alert-danger');

            if (alertSuccess) {
                alertSuccess.style.transition = "opacity 0.5s ease";
                alertSuccess.style.opacity = '0';
                setTimeout(() => alertSuccess.remove(), 600);
            }

            if (alertError) {
                alertError.style.transition = "opacity 0.5s ease";
                alertError.style.opacity = '0';
                setTimeout(() => alertError.remove(), 600);
            }
        }, 3000);
    </script>

</body>

</html>
