<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

$mensaje = $_SESSION['mensaje'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['mensaje'], $_SESSION['error']);

$resultado = $conexion->query("SELECT * FROM cargo ORDER BY nombre ASC");
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <title>Cargos</title>
    <link href="../public/bootstrap5/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet" />
    <style>
        ul li:nth-child(4) .activo {
            background: rgb(11, 150, 214) !important;
        }
    </style>
</head>

<body class="with-side-menu">
    <?php require('./layout/topbar.php'); ?>
    <?php require('./layout/sidebar.php'); ?>

    <div class="page-content container mt-4">

        <h4 class="text-secondary text-center mb-4">Listado de Cargos</h4>

        <?php if ($mensaje): ?>
            <div class="alert alert-success text-center" role="alert"><?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger text-center" role="alert"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="mb-3 text-end">
            <a href="registrar_cargo.php" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Nuevo Cargo
            </a>
        </div>

        <table class="table table-striped table-bordered table-hover align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Nombre del Cargo</th>
                    <th style="width: 150px;" class="text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($cargo = $resultado->fetch_object()): ?>
                    <tr>
                        <td><?= htmlspecialchars($cargo->nombre) ?></td>
                        <td class="text-center">
                            <a href="actualizar_cargo.php?id=<?= $cargo->id_cargo ?>" class="btn btn-warning btn-sm me-1" title="Modificar">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                            <button class="btn btn-danger btn-sm btn-eliminar" data-id="<?= $cargo->id_cargo ?>" title="Eliminar">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

    </div>

    <!-- Modal eliminar (Bootstrap 5) -->
    <div id="modalEliminar" class="modal fade" tabindex="-1" aria-labelledby="modalEliminarLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="formEliminar" method="GET" action="../controlador/controlador_eliminar_cargo.php">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalEliminarLabel">Confirmar eliminación</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">
                        ¿Está seguro que desea eliminar este cargo?
                        <input type="hidden" name="id" id="idEliminar" />
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-danger">Eliminar</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="../public/bootstrap5/js/bootstrap.bundle.min.js"></script>
    <script>
        // Activar la clase activo en el menú (cargo es 4)
        document.querySelector('ul li:nth-child(4) a').classList.add('activo');

        // Modal eliminar con Bootstrap 5
        const eliminarModal = new bootstrap.Modal(document.getElementById('modalEliminar'));
        const idEliminarInput = document.getElementById('idEliminar');

        document.querySelectorAll('.btn-eliminar').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.getAttribute('data-id');
                idEliminarInput.value = id;
                eliminarModal.show();
            });
        });

        // Ocultar alertas después de 3 segundos
        setTimeout(() => {
            document.querySelectorAll('.alert').forEach(alert => {
                alert.classList.add('fade');
                setTimeout(() => alert.remove(), 500);
            });
        }, 3000);
    </script>
</body>

</html>
