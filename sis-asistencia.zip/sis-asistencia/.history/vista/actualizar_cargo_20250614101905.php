<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if (!isset($_GET['id'])) {
    $_SESSION['error'] = "ID no válido";
    header("Location: cargo.php");
    exit();
}

$id_cargo = intval($_GET['id']);

$stmt = $conexion->prepare("SELECT * FROM cargo WHERE id_cargo = ?");
$stmt->bind_param("i", $id_cargo);
$stmt->execute();
$result = $stmt->get_result();
$cargo = $result->fetch_object();

if (!$cargo) {
    $_SESSION['error'] = "Cargo no encontrado";
    header("Location: cargo.php");
    exit();
}

// Procesar actualización
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = trim($_POST['nombre']);

    if (!empty($nombre)) {
        $stmt_update = $conexion->prepare("UPDATE cargo SET nombre = ? WHERE id_cargo = ?");
        $stmt_update->bind_param("si", $nombre, $id_cargo);

        if ($stmt_update->execute()) {
            $_SESSION['mensaje'] = "Cargo actualizado correctamente";
            header("Location: cargo.php");
            exit();
        } else {
            $_SESSION['error'] = "Error al actualizar el cargo";
        }
    } else {
        $_SESSION['error'] = "El nombre del cargo es obligatorio";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <title>Actualizar Cargo</title>
    <link href="../public/bootstrap5/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <?php require('./layout/topbar.php'); ?>
    <?php require('./layout/sidebar.php'); ?>

    <div class="container mt-5">
        <h3>Actualizar Cargo</h3>

        <?php if (!empty($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <form action="actualizar_cargo.php?id=<?= $cargo->id_cargo ?>" method="POST">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre del Cargo</label>
                <input type="text" name="nombre" id="nombre" class="form-control" value="<?= htmlspecialchars($cargo->nombre) ?>" required>
            </div>

            <button type="submit" class="btn btn-primary">Actualizar</button>
            <a href="cargo.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>

</html>
