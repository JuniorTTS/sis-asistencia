<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

$mensaje = $_SESSION['mensaje'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['mensaje'], $_SESSION['error']);

$resultado = $conexion->query("SELECT * FROM cargo ORDER BY nombre ASC");
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Cargos</title>
    <link href="../public/bootstrap5/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        ul li:nth-child(4) .activo {
            background: rgb(11, 150, 214) !important;
        }

        .modal-custom {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.6);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }

        .modal-content-custom {
            background: #fff;
            padding: 30px 20px;
            width: 400px;
            border-radius: 12px;
            position: relative;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            animation: fadeIn 0.3s ease-in-out;
        }

        .close-custom {
            position: absolute;
            right: 15px;
            top: 10px;
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }
    </style>
</head>

<body class="with-side-menu">
    <?php require('./layout/topbar.php'); ?>
    <?php require('./layout/sidebar.php'); ?>

    <div class="page-content container mt-4">
        <h4 class="mb-4 text-center text-secondary">Lista de Cargos</h4>

        <?php if ($mensaje): ?>
            <div class="alert alert-success text-center" role="alert"><?= htmlspecialchars($mensaje) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger text-center" role="alert"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="mb-3 text-end">
            <a href="registrar_cargo.php" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i> Nuevo Cargo
            </a>
        </div>

        <table class="table table-striped table-hover table-bordered align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Nombre</th>
                    <th class="text-center" style="width: 150px;">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($cargo = $resultado->fetch_object()): ?>
                    <tr>
                        <td><?= htmlspecialchars($cargo->nombre) ?></td>
                        <td class="text-center">
                            <a href="actualizar_cargo.php?id=<?= $cargo->id_cargo ?>" class="btn btn-warning btn-sm me-1" title="Modificar">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                            <button class="btn btn-danger btn-sm btn-eliminar" data-id="<?= $cargo->id_cargo ?>" title="Eliminar">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Modal eliminar -->
    <div id="modalEliminar" class="modal-custom">
        <div class="modal-content-custom">
            <span class="close-custom" id="cerrarModal">&times;</span>
            <h5>¿Está seguro de eliminar este cargo?</h5>
            <form id="formEliminar" method="GET" action="../controlador/controlador_eliminar_cargo.php">
                <input type="hidden" name="id" id="idEliminar" />
                <button type="submit" class="btn btn-danger mt-3">Eliminar</button>
                <button type="button" class="btn btn-secondary mt-3" id="cancelarEliminar">Cancelar</button>
            </form>
        </div>
    </div>

    <script>
        // Modal eliminar
        const modal = document.getElementById('modalEliminar');
        const cerrarModal = document.getElementById('cerrarModal');
        const cancelarEliminar = document.getElementById('cancelarEliminar');
        const inputIdEliminar = document.getElementById('idEliminar');

        document.querySelectorAll('.btn-eliminar').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.getAttribute('data-id');
                inputIdEliminar.value = id;
                modal.style.display = 'flex';
            });
        });

        cerrarModal.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        cancelarEliminar.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });

        // Ocultar mensajes en 3 segundos
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                alert.style.transition = 'opacity 0.5s ease';
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 600);
            });
        }, 3000);
    </script>
</body>

</html>
