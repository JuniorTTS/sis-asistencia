<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);

    if (!empty($nombre)) {
        $insert = $conexion->prepare("INSERT INTO cargo (nombre) VALUES (?)");
        $insert->bind_param("s", $nombre);

        if ($insert->execute()) {
            header("Location: cargo.php?mensaje=Cargo registrado correctamente");
            exit();
        } else {
            header("Location: cargo.php?error=Error al registrar el cargo");
            exit();
        }
    } else {
        header("Location: cargo.php?error=Debe ingresar un nombre");
        exit();
    }
}
?>

<div class="page-content">
    <h4 class="text-center texte-secondary">Registrar Nuevo Cargo</h4>

    <form method="POST">
        <div class="form-group">
            <label>Nombre del Cargo</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-success mt-3">Registrar</button>
        <a href="cargo.php" class="btn btn-secondary mt-3">Volver</a>
    </form>
</div>

<?php require('./layout/footer.php'); ?>
