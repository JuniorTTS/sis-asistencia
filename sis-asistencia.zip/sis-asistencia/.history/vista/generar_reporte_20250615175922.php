<?php
require("../modelo/conexion.php");
require("fpdf/fpdf.php");

// Consulta de asistencia
$sql = $conexion->query("SELECT
	asistencia.id_asistencia, 
	asistencia.entrada, 
	asistencia.salida, 
	empleado.nombre as nom_docente, 
	empleado.apellido, 
	empleado.dni, 
	cargo.nombre as nom_especialidad
FROM asistencia
	INNER JOIN empleado ON asistencia.id_empleado = empleado.id_empleado
	INNER JOIN cargo ON empleado.cargo = cargo.id_cargo");

// Creación del PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,'Reporte de Asistencia',0,1,'C');
$pdf->Ln(5);

// Encabezados de la tabla
$pdf->SetFont('Arial','B',10);
$pdf->Cell(10,10,'ID',1);
$pdf->Cell(40,10,'Personal',1);
$pdf->Cell(25,10,'DNI',1);
$pdf->Cell(40,10,'Especialidad',1);
$pdf->Cell(30,10,'Entrada',1);
$pdf->Cell(30,10,'Salida',1);
$pdf->Ln();

// Datos
$pdf->SetFont('Arial','',9);
while($datos = $sql->fetch_object()){
    $pdf->Cell(10,10,$datos->id_asistencia,1);
    $pdf->Cell(40,10,$datos->nom_docente . " " . $datos->apellido,1);
    $pdf->Cell(25,10,$datos->dni,1);
    $pdf->Cell(40,10,$datos->nom_especialidad,1);
    $pdf->Cell(30,10,$datos->entrada,1);
    $pdf->Cell(30,10,$datos->salida,1);
    $pdf->Ln();
}

$pdf->Output();
?>
