<!-- Agrega esto al final del archivo HTML, justo antes de cerrar </body> -->

<!-- Modal Cambiar Contraseña -->
<div id="modalCambiarPassword" class="modal-custom" style="display:none;">
  <div class="modal-content-custom text-center">
    <span class="close-custom" onclick="cerrarModal()">&times;</span>
    <form action="../controlador/controlador_cambiar_contrasena.php" method="POST">
      <h5 class="mb-3">Cambiar Contraseña</h5>
      <div class="form-group mb-2">
        <input type="password" name="contrasena_actual" class="form-control" placeholder="Contraseña actual" required>
      </div>
      <div class="form-group mb-2">
        <input type="password" name="nueva_contrasena" class="form-control" placeholder="Nueva contraseña" required>
      </div>
      <!-- CAPTCHA -->
      <div class="form-group mb-3">
        <label for="captcha">Resuelva: <span id="captchaOperacion"></span></label>
        <input type="text" class="form-control" id="respuestaCaptcha" placeholder="Resultado" required>
        <input type="hidden" id="captchaResultado">
      </div>
      <button type="submit" class="btn btn-primary" onclick="return validarCaptcha()">Actualizar</button>
    </form>
  </div>
</div>

<script>
function abrirModal() {
  document.getElementById('modalCambiarPassword').style.display = 'flex';
  generarCaptcha();
}

function cerrarModal() {
  document.getElementById('modalCambiarPassword').style.display = 'none';
}

function generarCaptcha() {
  const num1 = Math.floor(Math.random() * 10) + 1;
  const num2 = Math.floor(Math.random() * 10) + 1;
  document.getElementById('captchaOperacion').textContent = `${num1} + ${num2}`;
  document.getElementById('captchaResultado').value = num1 + num2;
}

function validarCaptcha() {
  const esperado = document.getElementById('captchaResultado').value;
  const respuesta = document.getElementById('respuestaCaptcha').value;
  if (parseInt(respuesta) !== parseInt(esperado)) {
    alert("Captcha incorrecto. Inténtalo de nuevo.");
    return false;
  }
  return true;
}

// Enlace del menú para abrir modal
window.addEventListener('DOMContentLoaded', () => {
  const cambiarLink = document.querySelector('a.dropdown-item[href="#"]');
  if (cambiarLink) {
    cambiarLink.addEventListener('click', (e) => {
      e.preventDefault();
      abrirModal();
    });
  }
});
</script>

<style>
.modal-custom {
  position: fixed;
  top: 0; left: 0; right: 0; bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: none;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}

.modal-content-custom {
  background: #fff;
  padding: 30px 20px;
  width: 400px;
  border-radius: 12px;
  position: relative;
  box-shadow: 0 8px 16px rgba(0,0,0,0.2);
  animation: fadeIn 0.3s ease-in-out;
}

.close-custom {
  position: absolute;
  right: 15px;
  top: 10px;
  font-size: 24px;
  cursor: pointer;
  color: #999;
}
</style>
