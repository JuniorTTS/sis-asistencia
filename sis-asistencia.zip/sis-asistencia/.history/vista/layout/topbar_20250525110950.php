<!doctype html>
<html lang="es">

<head lang="es">
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1, user-scalable=no" name="viewport">
    <meta content="ie=edge" http-equiv="x-ua-compatible">
    <title>Plantilla-php</title>

    <!-- Favicon -->
    <link href="https://tresplazas.com/web/img/big_punto_de_venta.png" rel="shortcut icon">

    <link href="../public/app/publico/css/lib/font-awesome/font-awesome.min.css" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="../public/app/publico/css/lib/lobipanel/lobipanel.min.css">
    <link rel="stylesheet" href="../public/app/publico/css/separate/vendor/lobipanel.min.css">
    <link rel="stylesheet" href="../public/app/publico/css/lib/jqueryui/jquery-ui.min.css">
    <link rel="stylesheet" href="../public/app/publico/css/separate/pages/widgets.min.css">

    <!-- DataTables -->
    <link rel="stylesheet" href="../public/app/publico/css/lib/datatables-net/datatables.min.css">
    <link rel="stylesheet" href="../public/app/publico/css/separate/vendor/datatables-net.min.css">

    <!-- CSS propio -->
    <link href="../public/app/publico/css/main.css" rel="stylesheet">
    <link href="../public/app/publico/css/mis_estilos/estilos.css" rel="stylesheet">
    <link href="../public/principal/css/estilos.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <!-- Chart.js -->
    <script src="../public/chart/chart.js"></script>
</head>

<body>
    <header>
        <div class="container-fluid">
            <a href="#" class="site-logo"></a>
        </div>
    </header>
</body>
</html>
