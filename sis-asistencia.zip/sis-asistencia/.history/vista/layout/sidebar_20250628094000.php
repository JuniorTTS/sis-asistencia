<nav class="side-menu">
            
            <ul class="side-menu-list p-0">
                <li class="red">
                    <a href="inicio.php" class="activo">
                        <img src="../public/img-inicio/programar.png" class="img-inicio" alt="">
                        <!-- <i class="fas fa-house-user"></i> -->
                        <span class="lbl">ASISTENCIAS</span>
                    </a>
                </li>

                <li class="red">
                    <a href="usuario.php" class="activo">
                        <img src="../public/img-inicio/usua.png" class="img-inicio" alt="">
                        <!-- <i class="fas fa-house-user"></i> -->
                        <span class="lbl">USUARIOS</span>
                    </a>
                </li>
                <li class="red">
                    <a href="empleado.php" class="activo">
                        <img src="../public/img-inicio/team.png" class="img-inicio" alt="">
                        <!-- <i class="fas fa-house-user"></i> -->
                        <span class="lbl">EMPLEADOS</span>
                    </a>
                </li>
                <li class="red">
                    <a href="cargo.php" class="activo">
                        <img src="../public/img-inicio/cargos.png" class="img-inicio" alt="">
                        <!-- <i class="fas fa-house-user"></i> -->
                        <span class="lbl">CARGOS</span>
                    </a>
                </li>
                <li class="red">
                    <a href="cargo.php" class="activo">
                        <img src="../public/img-inicio/cargos.png" class="img-inicio" alt="">
                        <!-- <i class="fas fa-house-user"></i> -->
                        <span class="lbl">INDICADORES</span>
                    </a>
                </li>
             
             

                

                <li class="red">
                    <a href="acerca.php" class="activo">
                        <img src="../public/img-inicio/info.png" class="img-inicio" alt="">
                        <!-- <i class="fas fa-exclamation"></i> -->
                        <span class="lbl">ACERCA DE</span>
                    </a>
                </li>




            </ul>
        </nav>

        