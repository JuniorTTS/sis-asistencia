<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validar que todos los campos existan y no estén vacíos
    if (
        isset($_POST['nombre'], $_POST['apellido'], $_POST['dni'], $_POST['cargo']) &&
        $_POST['nombre'] !== '' &&
        $_POST['apellido'] !== '' &&
        $_POST['dni'] !== '' &&
        $_POST['cargo'] !== ''
    ) {
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $dni = $_POST['dni'];
        $cargo = intval($_POST['cargo']); // convertir a entero por seguridad

        $insert = $conexion->prepare("INSERT INTO empleado (nombre, apellido, dni, cargo) VALUES (?, ?, ?, ?)");
        if ($insert === false) {
            // Error en la consulta preparada
            header("Location: empleado.php?error=Error interno en la base de datos");
            exit();
        }
        $insert->bind_param("sssi", $nombre, $apellido, $dni, $cargo);

        if ($insert->execute()) {
            header("Location: empleado.php?mensaje=Empleado registrado correctamente");
            exit();
        } else {
            header("Location: empleado.php?error=Error al registrar el empleado");
            exit();
        }
    } else {
        header("Location: empleado.php?error=Por favor, complete todos los campos");
        exit();
    }
}

// Si no es POST, cargar los cargos para el select
$cargos = $conexion->query("SELECT id_cargo, nombre FROM cargo ORDER BY nombre ASC");
?>

<div class="page-content">
    <h4 class="text-center texte-secondary">Registrar Nuevo Empleado</h4>

    <form method="POST" action="">
        <div class="form-group">
            <label>Nombre</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Apellido</label>
            <input type="text" name="apellido" class="form-control" required>
        </div>

        <div class="form-group">
            <label>DNI</label>
            <input type="text" name="dni" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Cargo</label>
            <select name="cargo" class="form-control" required>
                <option value="" disabled selected>Seleccione un cargo</option>
                <?php while ($cargo = $cargos->fetch_object()): ?>
                    <option value="<?= $cargo->id_cargo ?>"><?= htmlspecialchars($cargo->nombre) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-success mt-3">Registrar</button>
        <a href="empleado.php" class="btn btn-secondary mt-3">Volver</a>
    </form>
</div>

<?php require('./layout/footer.php'); ?>
