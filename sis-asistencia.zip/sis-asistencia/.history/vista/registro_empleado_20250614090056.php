<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $dni = $_POST['dni'];
    $cargo = $_POST['cargo'];

    $insert = $conexion->prepare("INSERT INTO empleado (nombre, apellido, dni, cargo) VALUES (?, ?, ?, ?)");
    $insert->bind_param("ssss", $nombre, $apellido, $dni, $cargo);

    if ($insert->execute()) {
        header("Location: empleado.php?mensaje=Empleado registrado correctamente");
    } else {
        header("Location: empleado.php?error=Error al registrar el empleado");
    }
    exit();
}
?>

<div class="page-content">
    <h4 class="text-center texte-secondary">Registrar Nuevo Empleado</h4>

    <form method="POST">
        <div class="form-group">
            <label>Nombre</label>
            <input type="text" name="nombre" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Apellido</label>
            <input type="text" name="apellido" class="form-control" required>
        </div>

        <div class="form-group">
            <label>DNI</label>
            <input type="text" name="dni" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Cargo</label>
            <input type="text" name="cargo" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-success mt-3">Registrar</button>
        <a href="empleado.php" class="btn btn-secondary mt-3">Volver</a>
    </form>
</div>

<?php require('./layout/footer.php'); ?>
