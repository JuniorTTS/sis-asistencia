<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
?>

<style>
  ul li:nth-child(5) .activo {
    background: rgb(11, 150, 214) !important;
  }

  /* Estilos para los modales... [mantén tus estilos existentes de modales] */

  /* Nuevos estilos para los botones de acción */
  .btn-action {
    padding: 8px 15px;
    font-size: 14px;
    min-width: 90px;
    border-radius: 4px;
    transition: all 0.2s ease;
    margin: 2px;
  }

  .btn-action i {
    margin-right: 5px;
  }

  .btn-modificar {
    background-color: #ffc107;
    border-color: #ffc107;
    color: #212529;
  }

  .btn-modificar:hover {
    background-color: #e0a800;
    border-color: #d39e00;
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  }

  .btn-eliminar {
    background-color: #dc3545;
    border-color: #dc3545;
    color: white;
  }

  .btn-eliminar:hover {
    background-color: #c82333;
    border-color: #bd2130;
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  }

  /* Espaciado entre botones */
  .acciones-cell {
    white-space: nowrap;
  }
</style>

<div class="page-content">
  <h4 class="text-center texte-secondary">INDICADORES</h4>

  <?php if (isset($_GET['mensaje'])): ?>
    <div id="alerta-mensaje" class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
  <?php elseif (isset($_GET['error'])): ?>
    <div id="alerta-mensaje" class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
  <?php endif; ?>

  <table class="table table-bordered table-hover col-md-12" id="example">
    <thead>
      <tr>
        <th>ID</th>
        <th>USUARIO</th>
        <th>DESCRIPCIÓN</th>
        <th>FECHA</th>
        <th>ACCIONES</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = $conexion->query("SELECT
        indicadores.id_indicador,
        empleado.nombre AS nombre_usuario,
        indicadores.descripcion,
        DATE_FORMAT(indicadores.fecha, '%d/%m/%Y %H:%i') as fecha_formateada
      FROM
        indicadores
        INNER JOIN empleado ON indicadores.id_usuario = empleado.id_empleado");
      while ($datos = $sql->fetch_object()):
      ?>
        <tr>
          <td><?= $datos->id_indicador ?></td>
          <td><?= htmlspecialchars($datos->nombre_usuario) ?></td>
          <td><?= htmlspecialchars($datos->descripcion) ?></td>
          <td><?= htmlspecialchars($datos->fecha_formateada) ?></td>
          <td class="acciones-cell">
            <button class="btn btn-action btn-modificar btn-edit" 
                    data-id="<?= $datos->id_indicador ?>" 
                    data-descripcion="<?= htmlspecialchars($datos->descripcion) ?>">
              <i class="fa-solid fa-user-pen"></i> Modificar
            </button>

            <button class="btn btn-action btn-eliminar btn-delete" 
                    data-id="<?= $datos->id_indicador ?>">
              <i class="fa-regular fa-trash-can"></i> Eliminar
            </button>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- [Tus modales existentes...] -->

<script>
// [Tu código JavaScript existente...]
</script>
