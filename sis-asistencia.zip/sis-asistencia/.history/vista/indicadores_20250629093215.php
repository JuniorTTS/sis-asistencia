<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
?>

<style>
  ul li:nth-child(5) .activo {
    background: rgb(11, 150, 214) !important;
  }

  .modal-custom {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }

  .modal-content-custom {
    background: #fff;
    padding: 30px 20px;
    width: 400px;
    border-radius: 12px;
    position: relative;
    box-shadow: 0 8px 16px rgba(0,0,0,0.2);
  }

  .close-custom {
    position: absolute;
    right: 15px;
    top: 10px;
    font-size: 24px;
    cursor: pointer;
    color: #999;
  }

  .modal-textarea {
    width: 100%;
    min-height: 100px;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    resize: vertical;
  }
</style>

<div class="page-content">
  <h4 class="text-center texte-secondary">INDICADORES</h4>

  <?php if (isset($_GET['mensaje'])): ?>
    <div id="alerta-mensaje" class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
  <?php elseif (isset($_GET['error'])): ?>
    <div id="alerta-mensaje" class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
  <?php endif; ?>

  <table class="table table-bordered table-hover col-md-12" id="example">
    <thead>
      <tr>
        <th>ID</th>
        <th>USUARIO</th>
        <th>DESCRIPCIÓN</th>
        <th>FECHA</th>
        <th>ACCIONES</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = $conexion->query("SELECT
        indicadores.id_indicador,
        empleado.nombre AS nombre_usuario,
        indicadores.descripcion,
        DATE_FORMAT(indicadores.fecha, '%d/%m/%Y %H:%i') as fecha_formateada
      FROM
        indicadores
        INNER JOIN empleado ON indicadores.id_usuario = empleado.id_empleado");
      while ($datos = $sql->fetch_object()):
      ?>
        <tr>
          <td><?= $datos->id_indicador ?></td>
          <td><?= htmlspecialchars($datos->nombre_usuario) ?></td>
          <td><?= htmlspecialchars($datos->descripcion) ?></td>
          <td><?= htmlspecialchars($datos->fecha_formateada) ?></td>
          <td>
            <button class="btn btn-warning btn-sm btn-edit" 
                    data-id="<?= $datos->id_indicador ?>" 
                    data-descripcion="<?= htmlspecialchars($datos->descripcion) ?>">
              <i class="fa-solid fa-user-pen"></i> Modificar
            </button>

            <a href="../controlador/controlador_eliminar_indicador.php?id=<?= $datos->id_indicador ?>"
               onclick="return confirm('¿Estás seguro de eliminar este indicador?')" 
               class="btn btn-danger btn-sm">
              <i class="fa-regular fa-trash-can"></i> Eliminar
            </a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- Modal de editar -->
<div id="editarModal" class="modal-custom">
  <div class="modal-content-custom">
    <span class="close-custom" id="closeEditarModal">&times;</span>
    <h4 class="text-center mb-3">Modificar Descripción</h4>
    <form action="../controlador/controlador_actualizar_indicador.php" method="POST">
      <input type="hidden" id="modal-id" name="id_indicador">
      <div class="form-group">
        <textarea id="modal-descripcion" name="descripcion" class="modal-textarea" required></textarea>
      </div>
      <div class="text-center mt-3">
        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
      </div>
    </form>
  </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
// Modal de edición
const editarModal = document.getElementById('editarModal');

// Función para mostrar modal y cargar datos
function mostrarModalEdicion(id, descripcion) {
    document.getElementById('modal-id').value = id;
    document.getElementById('modal-descripcion').value = descripcion;
    editarModal.style.display = 'flex';
}

// Abrir modal al hacer clic en botones de editar
document.querySelectorAll('.btn-edit').forEach(button => {
    button.addEventListener('click', function() {
        const id = this.getAttribute('data-id');
        const descripcion = this.getAttribute('data-descripcion');
        mostrarModalEdicion(id, descripcion);
    });
});

// Cerrar modal
document.getElementById('closeEditarModal').addEventListener('click', function() {
    editarModal.style.display = 'none';
});

// Cerrar modal al hacer clic fuera
window.addEventListener('click', function(event) {
    if (event.target === editarModal) {
        editarModal.style.display = 'none';
    }
});

// Ocultar mensajes después de 3 segundos
setTimeout(() => {
    const alerta = document.getElementById('alerta-mensaje');
    if (alerta) {
        alerta.style.transition = "opacity 0.5s";
        alerta.style.opacity = '0';
        setTimeout(() => alerta.remove(), 500);
    }
}, 3000);
</script>
