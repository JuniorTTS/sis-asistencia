<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');

    if ($nombre !== '') {
        $stmt = $conexion->prepare("INSERT INTO cargo (nombre) VALUES (?)");
        $stmt->bind_param("s", $nombre);

        if ($stmt->execute()) {
            $_SESSION['mensaje'] = "Cargo registrado correctamente";
            header("Location: cargo.php");
            exit();
        } else {
            $_SESSION['error'] = "Error al registrar el cargo";
        }
    } else {
        $_SESSION['error'] = "El nombre del cargo es obligatorio";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <title>Registrar Cargo</title>
    <link href="../public/bootstrap5/css/bootstrap.min.css" rel="stylesheet" />
</head>

<body>
    <?php require('./layout/topbar.php'); ?>
    <?php require('./layout/sidebar.php'); ?>

    <div class="container mt-4">
        <h3>Registrar</h3>

        <?php if (!empty($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <form action="registrar_cargo.php" method="POST" autocomplete="off" class="mt-3">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre del Cargo</label>
                <input type="text" name="nombre" id="nombre" class="form-control" placeholder="Ejemplo: Profesor" required autofocus>
            </div>
            <button type="submit" class="btn btn-primary">Registrar</button>
            <a href="cargo.php" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>

</html>
