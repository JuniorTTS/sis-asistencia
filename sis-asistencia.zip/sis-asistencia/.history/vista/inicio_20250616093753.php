<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
require_once "../controlador/controlador_eliminar_asistencia.php";
?>

<style>
  ul li:nth-child(1) .activo {
    background: rgb(11, 150, 214) !important;
  }
</style>

<div class="page-content">
  <h4 class="text-center texte-secondary">ASISTENCIA DEL PERSONAL</h4>

  <?php if (isset($_GET['mensaje'])): ?>
    <div id="alerta-mensaje" class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
  <?php elseif (isset($_GET['error'])): ?>
    <div id="alerta-mensaje" class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
  <?php endif; ?>

  <!-- Botón para generar el reporte PDF -->
  <a href="generar_reporte.php" target="_blank" class="btn btn-danger btn-rounded mb-2">
    <i class="fa-solid fa-file-pdf"></i> Reporte
  </a>

  <table class="table table-bordered table-hover col-md-12" id="example">
    <thead>
      <tr>
        <th>ID</th>
        <th>PERSONAL</th>
        <th>DNI</th>
        <th>ESPECIALIDAD</th>
        <th>ENTRADA</th>
        <th>SALIDA</th>
        <th>ACCIONES</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = $conexion->query("SELECT
        asistencia.*, 
        asistencia.id_asistencia, 
        asistencia.id_empleado, 
        asistencia.entrada, 
        asistencia.salida, 
        empleado.*, 
        empleado.id_empleado, 
        empleado.nombre as 'nom_docente', 
        empleado.cargo, 
        empleado.dni, 
        empleado.apellido, 
        cargo.*, 
        cargo.id_cargo, 
        cargo.nombre as 'nom_especialidad'
      FROM
        asistencia
        INNER JOIN empleado ON asistencia.id_empleado = empleado.id_empleado
        INNER JOIN cargo ON empleado.cargo = cargo.id_cargo ");

      while ($datos = $sql->fetch_object()):
      ?>
        <tr>
          <td><?= $datos->id_asistencia ?></td>
          <td><?= htmlspecialchars($datos->nom_docente . " " . $datos->apellido) ?></td>
          <td><?= htmlspecialchars($datos->dni) ?></td>
          <td><?= htmlspecialchars($datos->nom_especialidad) ?></td>
          <td><?= htmlspecialchars($datos->entrada) ?></td>
          <td><?= htmlspecialchars($datos->salida) ?></td>
          <td>
            <a href="inicio.php?id=<?= $datos->id_asistencia ?>" onclick="advertencia(event)" class="btn btn-danger">
              <i class="fa-regular fa-trash-can"></i>
            </a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require('./layout/footer.php'); ?>


<script>
$(document).ready(function() {
  $('#example').DataTable({
    "language": {
      "lengthMenu": "Mostrar _MENU_ registros por página",
      "zeroRecords": "No se encontraron resultados",
      "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
      "search": "Buscar:",
      "paginate": {
        "first": "Primero",
        "last": "Último",
        "next": "Siguiente",
        "previous": "Anterior"
      }
    },
    "pageLength": 10
  });
});

// Ocultar el mensaje después de 3 segundos
setTimeout(() => {
  const alerta = document.getElementById('alerta-mensaje');
  if (alerta) {
    alerta.style.transition = "opacity 0.5s ease";
    alerta.style.opacity = 0;
    setTimeout(() => alerta.remove(), 500);
  }

  if (window.history.replaceState) {
    const url = new URL(window.location);
    url.searchParams.delete('mensaje');
    url.searchParams.delete('error');
    window.history.replaceState({}, document.title, url.pathname);
  }
}, 3000);
</script>
