<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";

// Para mostrar mensajes (se guardan en sesión y se eliminan luego para evitar recarga persistente)
$mensaje = $_SESSION['mensaje'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['mensaje'], $_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Cargos - Sistema de Asistencia</title>
    <!-- Asumo que en topbar.php o en layout se cargan Bootstrap CSS/JS y FontAwesome -->
    
    <style>
      ul li:nth-child(4) .activo {
        background: rgb(11, 150, 214) !important;
      }

      .modal-custom {
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0, 0, 0, 0.6);
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 9999;
      }

      .modal-content-custom {
        background: #fff;
        padding: 30px 20px;
        width: 400px;
        border-radius: 12px;
        position: relative;
        box-shadow: 0 8px 16px rgba(0,0,0,0.2);
        animation: fadeIn 0.3s ease-in-out;
      }

      .close-custom {
        position: absolute;
        right: 15px;
        top: 10px;
        font-size: 24px;
        cursor: pointer;
        color: #999;
      }

      @keyframes fadeIn {
        from { opacity: 0; transform: scale(0.95); }
        to { opacity: 1; transform: scale(1); }
      }
    </style>
</head>
<body>

<div class="page-content container mt-4">
    <h4 class="text-center text-secondary mb-3">LISTA DE CARGOS</h4>

    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= htmlspecialchars($mensaje) ?></div>
    <?php elseif ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <a href="registro_cargo.php" class="btn btn-primary btn-rounded mb-3">
        <i class="fa-solid fa-plus"></i> Registrar
    </a>

    <table class="table table-bordered table-hover" id="tablaCargos">
        <thead class="table-primary">
            <tr>
                <th>ID</th>
                <th>Nombre del Cargo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = $conexion->query("SELECT * FROM cargo ORDER BY nombre ASC");
            while ($datos = $sql->fetch_object()):
            ?>
                <tr>
                    <td><?= $datos->id_cargo ?></td>
                    <td><?= htmlspecialchars($datos->nombre) ?></td>
                    <td>
                        <button type="button" class="btn btn-warning btn-modificar" 
                                data-id="<?= $datos->id_cargo ?>" 
                                data-nombre="<?= htmlspecialchars($datos->nombre) ?>"
                                data-bs-toggle="modal" data-bs-target="#modalModificarCargo">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>

                        <button type="button" class="btn btn-danger btn-eliminar"
                                data-id="<?= $datos->id_cargo ?>"
                                data-nombre="<?= htmlspecialchars($datos->nombre) ?>"
                                data-bs-toggle="modal" data-bs-target="#modalEliminarCargo">
                            <i class="fa-regular fa-trash-can"></i>
                        </button>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Modal Modificar Cargo -->
<div class="modal fade" id="modalModificarCargo" tabindex="-1" aria-labelledby="modalModificarCargoLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="../controlador/actualizar_cargo.php" method="POST" id="formModificarCargo">
        <div class="modal-header">
          <h5 class="modal-title" id="modalModificarCargoLabel">Modificar Cargo</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
            <input type="hidden" name="id_cargo" id="idCargoModificar" required>
            <div class="mb-3">
                <label for="nombreCargoModificar" class="form-label">Nombre del Cargo</label>
                <input type="text" name="nombre" id="nombreCargoModificar" class="form-control" required>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Eliminar Cargo -->
<div class="modal fade" id="modalEliminarCargo" tabindex="-1" aria-labelledby="modalEliminarCargoLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="../controlador/controlador_eliminar_cargo.php" method="POST" id="formEliminarCargo">
        <div class="modal-header">
          <h5 class="modal-title" id="modalEliminarCargoLabel">Eliminar Cargo</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <p>¿Está seguro que desea eliminar el cargo <strong id="nombreCargoEliminar"></strong>?</p>
          <input type="hidden" name="id" id="idCargoEliminar" required>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-danger">Eliminar</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Abrir modal modificar con datos cargados
    var modalModificar = document.getElementById('modalModificarCargo');
    modalModificar.addEventListener('show.bs.modal', function(event) {
        var button = event.relatedTarget;
        var id = button.getAttribute('data-id');
        var nombre = button.getAttribute('data-nombre');

        document.getElementById('idCargoModificar').value = id;
        document.getElementById('nombreCargoModificar').value = nombre;
    });

    // Abrir modal eliminar con datos cargados
    var modalEliminar = document.getElementById('modalEliminarCargo');
    modalEliminar.addEventListener('show.bs.modal', function(event) {
        var button = event.relatedTarget;
        var id = button.getAttribute('data-id');
        var nombre = button.getAttribute('data-nombre');

        document.getElementById('idCargoEliminar').value = id;
        document.getElementById('nombreCargoEliminar').textContent = nombre;
    });
});
</script>

</body>
</html>
