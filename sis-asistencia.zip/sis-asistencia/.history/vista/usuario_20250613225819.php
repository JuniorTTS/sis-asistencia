<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
require_once "../controlador/controlador_eliminar_asistencia.php";
?>

<style>
  ul li:nth-child(2) .activo {
    background: rgb(11, 150, 214) !important;
  }
</style>

<div class="page-content">
  <h4 class="text-center texte-secondary">LISTA DE USUARIOS </h4>

  <!-- Mostrar mensajes -->
  <?php if (isset($_GET['mensaje'])): ?>
    <div class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
  <?php elseif (isset($_GET['error'])): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
  <?php endif; ?>

  <a href="registro_usuario.php" class="btn btn-primary btn-rounded mb-2">
    <i class="fa-solid fa-plus"></i> Registrar
  </a>

  <table class="table table-bordered table-hover col-md-12" id="example">
    <thead>
      <tr>
        <th>ID</th>
        <th>NOMBRE</th>
        <th>APELLIDO</th>
        <th>USUARIO</th>
        <th>ACCIONES</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = $conexion->query("SELECT * FROM usuario");
      while ($datos = $sql->fetch_object()):
      ?>
        <tr>
          <td><?= $datos->id_usuario ?></td>
          <td><?= htmlspecialchars($datos->nombre) ?></td>
          <td><?= htmlspecialchars($datos->apellido) ?></td>
          <td><?= htmlspecialchars($datos->usuario) ?></td>
          <td>
            <!-- BOTÓN EDITAR -->
            <button class="btn btn-warning btn-edit"
                data-id="<?= $datos->id_usuario ?>"
                data-nombre="<?= htmlspecialchars($datos->nombre) ?>"
                data-apellido="<?= htmlspecialchars($datos->apellido) ?>"
                data-usuario="<?= htmlspecialchars($datos->usuario) ?>">
              <i class="fa-solid fa-user-pen"></i>
            </button>

            <!-- BOTÓN ELIMINAR -->
            <a href="inicio.php?id=<?= $datos->id_usuario ?>" onclick="advertencia(event)" class="btn btn-danger">
              <i class="fa-regular fa-trash-can"></i>
            </a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- MODAL -->
<div class="modal fade" id="editarModal" tabindex="-1" aria-labelledby="editarModalLabel" aria-hidden="true">
  <div class="moda
