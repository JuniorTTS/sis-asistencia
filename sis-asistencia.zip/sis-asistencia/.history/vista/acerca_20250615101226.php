<?php require('./layout/topbar.php'); ?>
<?php require('./layout/sidebar.php'); ?>
<?php
require_once "../modelo/conexion.php";

// Consultar datos de la empresa
$resultado = $conexion->query("SELECT * FROM empresa LIMIT 1");
$empresa = $resultado->fetch_object();
?>

<div class="page-content">
    <h4 class="text-center text-secondary mb-4">Información de la Empresa</h4>

    <div class="card mx-auto" style="max-width: 600px;">
        <div class="card-body">
            <h5 class="card-title"><i class="fa-solid fa-building"></i> <?= htmlspecialchars($empresa->nombre) ?></h5>
            <p class="card-text"><i class="fa-solid fa-phone"></i> Teléfono: <?= htmlspecialchars($empresa->telefono) ?></p>
            <p class="card-text"><i class="fa-solid fa-location-dot"></i> Ubicación: <?= htmlspecialchars($empresa->ubicacion) ?></p>
            <p class="card-text"><i class="fa-solid fa-envelope"></i> Correo: <?= htmlspecialchars($empresa->correo) ?></p>

            <button class="btn btn-primary btn-edit mt-3">
                <i class="fa-solid fa-pen-to-square"></i> Modificar Datos
            </button>
        </div>
    </div>
</div>

<!-- Modal para editar empresa -->
<div id="editarEmpresaModal" class="modal-custom" style="display:none; position:fixed; top:0;left:0;right:0;bottom:0; background:rgba(0,0,0,0.6); z-index:9999; justify-content:center; align-items:center;">
    <div class="modal-content-custom" style="background:white; padding:20px; border-radius:12px; width:400px; position:relative;">
        <button type="button" class="close-custom" id="closeEditarEmpresaModal" style="position:absolute; top:10px; right:15px; font-size:24px; cursor:pointer;">&times;</button>
        <form action="actualizar_empresa.php" method="POST">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre:</label>
                <input type="text" name="nombre" id="nombre" class="form-control" value="<?= htmlspecialchars($empresa->nombre) ?>" required>
            </div>
            <div class="mb-3">
                <label for="telefono" class="form-label">Teléfono:</label>
                <input type="text" name="telefono" id="telefono" class="form-control" value="<?= htmlspecialchars($empresa->telefono) ?>" required>
            </div>
            <div class="mb-3">
                <label for="ubicacion" class="form-label">Ubicación:</label>
                <input type="text" name="ubicacion" id="ubicacion" class="form-control" value="<?= htmlspecialchars($empresa->ubicacion) ?>" required>
            </div>
            <div class="mb-3">
                <label for="correo" class="form-label">Correo:</label>
                <input type="email" name="correo" id="correo" class="form-control" value="<?= htmlspecialchars($empresa->correo) ?>" required>
            </div>
            <button type="submit" class="btn btn-success">Guardar Cambios</button>
        </form>
    </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
// Abrir el modal
document.querySelector('.btn-edit').addEventListener('click', () => {
    document.getElementById('editarEmpresaModal').style.display = 'flex';
});

// Cerrar el modal
document.getElementById('closeEditarEmpresaModal').addEventListener('click', () => {
    document.getElementById('editarEmpresaModal').style.display = 'none';
});

// Cerrar si se hace clic fuera del modal
window.addEventListener('click', (e) => {
    const modal = document.getElementById('editarEmpresaModal');
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});
</script>
