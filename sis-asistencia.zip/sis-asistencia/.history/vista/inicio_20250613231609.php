<?php
session_start();
if (empty($_SESSION['nombre']) and empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');

include "../modelo/conexion.php";
include "../controlador/controlador_eliminar_asistencia.php";

date_default_timezone_set('America/Asuncion');
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['dni'], $_POST['accion'])) {
    $dni = trim($_POST['dni']);
    $accion = $_POST['accion']; // 'entrada' o 'salida'
    $hora_actual = date("H:i:s");
    $fecha_actual = date("Y-m-d");

    // Buscar el empleado por DNI para obtener su id_empleado
    $emp_sql = $conexion->prepare("SELECT id_empleado FROM empleado WHERE dni = ?");
    $emp_sql->bind_param("s", $dni);
    $emp_sql->execute();
    $res_emp = $emp_sql->get_result();

    if ($res_emp->num_rows == 1) {
        $empleado = $res_emp->fetch_assoc();
        $id_empleado = $empleado['id_empleado'];

        // Verificar si ya hay registro de asistencia para ese empleado y fecha
        $asist_sql = $conexion->prepare("SELECT * FROM asistencia WHERE id_empleado = ? AND fecha = ?");
        $asist_sql->bind_param("is", $id_empleado, $fecha_actual);
        $asist_sql->execute();
        $res_asist = $asist_sql->get_result();

        if ($res_asist->num_rows > 0) {
            // Ya existe registro para hoy
            $registro = $res_asist->fetch_assoc();
            $id_asistencia = $registro['id_asistencia'];

            if ($accion == "entrada" && empty($registro['entrada'])) {
                $upd = $conexion->prepare("UPDATE asistencia SET entrada = ? WHERE id_asistencia = ?");
                $upd->bind_param("si", $hora_actual, $id_asistencia);
                $upd->execute();
                $mensaje = "Hora de entrada registrada correctamente.";
            } elseif ($accion == "salida" && empty($registro['salida'])) {
                $upd = $conexion->prepare("UPDATE asistencia SET salida = ? WHERE id_asistencia = ?");
                $upd->bind_param("si", $hora_actual, $id_asistencia);
                $upd->execute();
                $mensaje = "Hora de salida registrada correctamente.";
            } else {
                $mensaje = "Ya está registrada la hora para esta acción.";
            }
        } else {
            // Insertar nuevo registro
            if ($accion == "entrada") {
                $ins = $conexion->prepare("INSERT INTO asistencia (id_empleado, fecha, entrada) VALUES (?, ?, ?)");
                $ins->bind_param("iss", $id_empleado, $fecha_actual, $hora_actual);
                $ins->execute();
                $mensaje = "Hora de entrada registrada correctamente.";
            } elseif ($accion == "salida") {
                $ins = $conexion->prepare("INSERT INTO asistencia (id_empleado, fecha, salida) VALUES (?, ?, ?)");
                $ins->bind_param("iss", $id_empleado, $fecha_actual, $hora_actual);
                $ins->execute();
                $mensaje = "Hora de salida registrada correctamente.";
            }
        }
    } else {
        $mensaje = "No se encontró ningún empleado con ese DNI.";
    }
}
?>

<style>
  ul li:nth-child(1) .activo {
    background: rgb(11, 150, 214) !important;
  }
</style>

<!-- inicio del contenido principal -->
<div class="page-content">

  <h4 class="text-center texte-secondary">ASISTENCIA DEL PERSONAL</h4>

  <!-- Mostrar mensaje -->
  <?php if ($mensaje): ?>
    <div class="alert alert-info"><?= htmlspecialchars($mensaje) ?></div>
  <?php endif; ?>

  <!-- Formulario para registrar entrada/salida -->
  <form method="POST" class="mb-3">
    <div class="form-group">
      <label for="dni">DNI del Empleado</label>
      <input type="text" name="dni" id="dni" class="form-control" required>
    </div>
    <button type="submit" name="accion" value="entrada" class="btn btn-success">Marcar Entrada</button>
    <button type="submit" name="accion" value="salida" class="btn btn-danger">Marcar Salida</button>
  </form>

  <?php
  // Consulta para mostrar asistencia junto con datos de empleado y cargo
  $sql = $conexion->query("SELECT
    asistencia.*, 
    asistencia.id_asistencia, 
    asistencia.id_empleado, 
    asistencia.entrada, 
    asistencia.salida, 
    empleado.*, 
    empleado.id_empleado, 
    empleado.nombre as 'nom_docente', 
    empleado.cargo, 
    empleado.dni, 
    empleado.apellido, 
    cargo.*, 
    cargo.id_cargo, 
    cargo.nombre as 'nom_especialidad'
    FROM asistencia
    INNER JOIN empleado ON asistencia.id_empleado = empleado.id_empleado
    INNER JOIN cargo ON empleado.cargo = cargo.id_cargo
    ORDER BY asistencia.fecha DESC, asistencia.id_asistencia DESC
  ");
  ?>

  <table class="table table-bordered table-hover col-12" id="example">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">PERSONAL</th>
        <th scope="col">DNI</th>
        <th scope="col">ESPECIALIDAD</th>
        <th scope="col">ENTRADA</th>
        <th scope="col">SALIDA</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php while ($datos = $sql->fetch_object()) { ?>
        <tr>
          <td><?= $datos->id_asistencia ?></td>
          <td><?= htmlspecialchars($datos->nom_docente . " " . $datos->apellido) ?></td>
          <td><?= htmlspecialchars($datos->dni) ?></td>
          <td><?= htmlspecialchars($datos->nom_especialidad) ?></td>
          <td><?= htmlspecialchars($datos->entrada) ?></td>
          <td><?= htmlspecialchars($datos->salida) ?></td>
          <td>
            <a href="inicio.php?id=<?= $datos->id_asistencia ?>" onclick="advertencia(event)" class="btn btn-danger">
              <i class="fa-regular fa-trash-can"></i>
            </a>
          </td>
        </tr>
      <?php } ?>
    </tbody>
  </table>

</div>

<!-- fin del contenido principal -->

<?php require('./layout/footer.php'); ?>
