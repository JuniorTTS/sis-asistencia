<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:../login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";

$mensaje = $_SESSION['mensaje'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['mensaje'], $_SESSION['error']);

$resultado = $conexion->query("SELECT * FROM cargo ORDER BY nombre ASC");
?>

<style>
  ul li:nth-child(4) .activo {
    background: rgb(11, 150, 214) !important;
  }

  .modal-custom {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }

  .modal-content-custom {
    background: #fff;
    padding: 30px 20px;
    width: 400px;
    border-radius: 12px;
    position: relative;
    box-shadow: 0 8px 16px rgba(0,0,0,0.2);
    animation: fadeIn 0.3s ease-in-out;
  }

  .close-custom {
    position: absolute;
    right: 15px;
    top: 10px;
    font-size: 24px;
    cursor: pointer;
    color: #999;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: scale(0.95); }
    to { opacity: 1; transform: scale(1); }
  }
</style>

<div class="page-content">
  <h4 class="text-center text-secondary mb-4">Listado de Cargos</h4>

  <?php if ($mensaje): ?>
    <div id="alerta-mensaje" class="alert alert-success text-center"><?= htmlspecialchars($mensaje) ?></div>
  <?php endif; ?>

  <?php if ($error): ?>
    <div id="alerta-mensaje" class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <a href="registrar_cargo.php" class="btn btn-primary btn-rounded mb-3">
    <i class="fa-solid fa-plus"></i> Registrar
  </a>

  <table class="table table-bordered table-hover col-md-6 mx-auto">
    <thead class="table-dark">
      <tr>
        <th>Cargos</th>
        <th style="width: 150px;" class="text-center">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($cargo = $resultado->fetch_object()): ?>
        <tr>
          <td><?= htmlspecialchars($cargo->nombre) ?></td>
          <td class="text-center">
            <button class="btn btn-warning btn-edit" 
                    data-id="<?= $cargo->id_cargo ?>" 
                    data-nombre="<?= htmlspecialchars($cargo->nombre) ?>" 
                    title="Modificar">
              <i class="fa-solid fa-pencil"></i>
            </button>
            <button class="btn btn-danger btn-eliminar" 
                    data-id="<?= $cargo->id_cargo ?>" 
                    title="Eliminar">
              <i class="fa-regular fa-trash-can"></i>
            </button>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- Modal de editar -->
<div id="editarModal" class="modal-custom" tabindex="-1" role="dialog" aria-modal="true" aria-labelledby="editarModalLabel">
  <div class="modal-content-custom">
    <button type="button" class="close-custom" aria-label="Cerrar" id="closeEditarModal">&times;</button>
    <form action="actualizar_cargo.php" method="POST">
      <input type="hidden" id="modal-id" name="id_cargo">
      <div class="form-group">
        <label for="modal-nombre">Cargos</label>
        <input type="text" id="modal-nombre" name="nombre" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary mt-3">Guardar Cambios</button>
    </form>
  </div>
</div>

<!-- Modal de Confirmación de Eliminación -->
<div id="confirmarEliminarModal" class="modal-custom" tabindex="-1" role="dialog" aria-modal="true" aria-labelledby="confirmarEliminarLabel">
  <div class="modal-content-custom text-center">
    <button type="button" class="close-custom" aria-label="Cerrar" id="closeConfirmModal">&times;</button>
    <h5 id="confirmarEliminarLabel" class="mb-3">Confirmar Eliminación</h5>
    <p>¿Estás seguro de que deseas eliminar este cargo?</p>
    <div class="d-flex justify-content-center mt-4">
      <button id="cancelarEliminar" class="btn btn-secondary mx-2">Cancelar</button>
      <button id="confirmarEliminarBtn" class="btn btn-danger mx-2">Eliminar</button>
    </div>
  </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
  // Variables modales
  const editarModal = document.getElementById('editarModal');
  const confirmarEliminarModal = document.getElementById('confirmarEliminarModal');
  let eliminarUrl = "";

  // Abrir modal editar y rellenar campos
  document.querySelectorAll('.btn-edit').forEach(button => {
    button.addEventListener('click', () => {
      document.getElementById('modal-id').value = button.dataset.id;
      document.getElementById('modal-nombre').value = button.dataset.nombre;
      editarModal.style.display = 'flex';
    });
  });

  // Cerrar modal editar
  document.getElementById('closeEditarModal').addEventListener('click', () => {
    editarModal.style.display = 'none';
  });

  // Cerrar modal eliminar
  document.getElementById('closeConfirmModal').addEventListener('click', () => {
    confirmarEliminarModal.style.display = 'none';
  });

  document.getElementById('cancelarEliminar').addEventListener('click', () => {
    confirmarEliminarModal.style.display = 'none';
  });

  // Confirmar eliminación
  document.querySelectorAll('.btn-eliminar').forEach(button => {
    button.addEventListener('click', (e) => {
      eliminarUrl = "../controlador/controlador_eliminar_cargo.php?id=" + button.dataset.id;
      confirmarEliminarModal.style.display = 'flex';
    });
  });

  document.getElementById('confirmarEliminarBtn').addEventListener('click', () => {
    window.location.href = eliminarUrl;
  });

  // Cerrar modales si se hace clic fuera del contenido
  window.addEventListener('click', (e) => {
    if (e.target === editarModal) {
      editarModal.style.display = 'none';
    }
    if (e.target === confirmarEliminarModal) {
      confirmarEliminarModal.style.display = 'none';
    }
  });

  // Ocultar el mensaje después de 3 segundos y limpiar la URL
  setTimeout(() => {
    const alerta = document.getElementById('alerta-mensaje');
    if (alerta) {
      alerta.style.transition = "opacity 0.5s ease";
      alerta.style.opacity = 0;
      setTimeout(() => {
        alerta.remove();
      }, 500);
    }

    if (window.history.replaceState) {
      const url = new URL(window.location);
      url.searchParams.delete('mensaje');
      url.searchParams.delete('error');
      window.history.replaceState({}, document.title, url.pathname);
    }
  }, 3000);
</script>
