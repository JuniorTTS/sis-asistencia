<?php
session_start();
if (empty($_SESSION['nombre']) and empty($_SESSION['apellido'])) {
    header('location:login/login.php');
}
?>

<style>
  ul li:nth-child(2) .activo{
    background: rgb(11, 150, 214) !important;
  }
</style>

<?php require('./layout/topbar.php'); ?>
<?php require('./layout/sidebar.php'); ?>

<div class="page-content">

<h4 class="text-center texte-secondary">REGISTRO DE USUARIOS</h4>

<?php
// Incluimos la conexión
include "../modelo/conexion.php";

?>

<?php
// Procesamos el formulario al enviarlo
if (!empty($_POST["btnregistrar"])) {

    if (!empty($_POST["txtnombre"]) && !empty($_POST["txtapellido"]) && 
        !empty($_POST["txtusuario"]) && !empty($_POST["txtpassword"])) {
        
        $nombre = trim($_POST["txtnombre"]);
        $apellido = trim($_POST["txtapellido"]);
        $usuario = trim($_POST["txtusuario"]);
        $password = trim($_POST["txtpassword"]);
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        // Verificamos si el usuario ya existe
        $sql_verificar = "SELECT * FROM sis.asistencia WHERE usuario = ?";
        $stmt_verificar = $conexion->prepare($sql_verificar);
        $stmt_verificar->bind_param("s", $usuario);
        $stmt_verificar->execute();
        $resultado = $stmt_verificar->get_result();

        if ($resultado->num_rows > 0) {
            echo '<div class="alert alert-warning">El usuario ya existe.</div>';
        } else {
            // Insertamos el nuevo usuario
            $sql_insertar = "INSERT INTO usuarios (nombre, apellido, usuario, password) VALUES (?, ?, ?, ?)";
            $stmt_insertar = $conexion->prepare($sql_insertar);
            $stmt_insertar->bind_param("ssss", $nombre, $apellido, $usuario, $passwordHash);

            if ($stmt_insertar->execute()) {
                echo '<div class="alert alert-success">Usuario registrado correctamente.</div>';
            } else {
                echo '<div class="alert alert-danger">Error al registrar el usuario.</div>';
            }

            $stmt_insertar->close();
        }

        $stmt_verificar->close();
        $conexion->close();

    } else {
        echo '<div class="alert alert-warning">Todos los campos son obligatorios.</div>';
    }
}
?>

<div class="row">
  <form action="" method="POST">
    <div class="fl-flex-label mb-4 px-2 col-12 col-md-6">
      <input type="text" placeholder="Nombre" class="input input__text" name="txtnombre">
    </div>
    <div class="fl-flex-label mb-4 px-2 col-12 col-md-6">
      <input type="text" placeholder="Apellido" class="input input__text" name="txtapellido">
    </div>
    <div class="fl-flex-label mb-4 px-2 col-12 col-md-6">
      <input type="text" placeholder="Usuario" class="input input__text" name="txtusuario">
    </div>
    <div class="fl-flex-label mb-4 px-2 col-12 col-md-6">
      <input type="password" placeholder="Contraseña" class="input input__text" name="txtpassword">
    </div>
    <div class="text-right p-2">
      <a href="usuario.php" class="btn btn-secondary btn-rounded">Atrás</a>
      <button type="submit" value="ok" name="btnregistrar" class="btn btn-primary btn-rounded">Registrar</button>
    </div>
  </form>
</div>

</div>

<?php require ('./layout/footer.php'); ?>
