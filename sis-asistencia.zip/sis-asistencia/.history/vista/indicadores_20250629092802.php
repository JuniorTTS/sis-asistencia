<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
// Eliminamos el require del controlador de asistencia ya que no lo necesitamos aquí
?>

<style>
  ul li:nth-child(5) .activo {
    background: rgb(11, 150, 214) !important;
  }
  
  /* Tus estilos CSS existentes */
  .modal-custom {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }
  /* ... (mantén el resto de tus estilos) ... */
</style>

<div class="page-content">
  <h4 class="text-center texte-secondary">INDICADORES</h4>

  <?php if (isset($_GET['mensaje'])): ?>
    <div id="alerta-mensaje" class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
  <?php elseif (isset($_GET['error'])): ?>
    <div id="alerta-mensaje" class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
  <?php endif; ?>

  <table class="table table-bordered table-hover col-md-12" id="example">
    <thead>
      <tr>
        <th>ID</th>
        <th>USUARIO</th>
        <th>DESCRIPCIÓN</th>
        <th>FECHA</th>
        <th>ACCIONES</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = $conexion->query("SELECT
        indicadores.id_indicador,
        empleado.nombre AS nombre_usuario,
        indicadores.descripcion,
        DATE_FORMAT(indicadores.fecha, '%d/%m/%Y %H:%i') as fecha_formateada
      FROM
        indicadores
        INNER JOIN empleado ON indicadores.id_usuario = empleado.id_empleado");
      while ($datos = $sql->fetch_object()):
      ?>
        <tr>
          <td><?= $datos->id_indicador ?></td>
          <td><?= htmlspecialchars($datos->nombre_usuario) ?></td>
          <td><?= htmlspecialchars($datos->descripcion) ?></td>
          <td><?= htmlspecialchars($datos->fecha_formateada) ?></td>
          <td>
            <button class="btn btn-warning btn-edit" 
                    data-id="<?= $datos->id_indicador ?>" 
                    data-descripcion="<?= htmlspecialchars($datos->descripcion) ?>">
              <i class="fa-solid fa-pen-to-square"></i> Editar
            </button>

            <a href="../controlador/controlador_eliminar_indicador.php?id=<?= $datos->id_indicador ?>"
               onclick="return confirmarEliminar(event, this.href)" 
               class="btn btn-danger">
              <i class="fa-regular fa-trash-can"></i> Eliminar
            </a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- Modal de editar - Solo descripción -->
<div id="editarModal" class="modal-custom" tabindex="-1" role="dialog">
  <div class="modal-content-custom">
    <button type="button" class="close-custom" id="closeEditarModal">&times;</button>
    <h5 class="text-center mb-3">Editar Descripción</h5>
    <form action="../controlador/controlador_actualizar_indicador.php" method="POST">
      <input type="hidden" id="modal-id" name="id_indicador">
      <div class="form-group">
        <label>Descripción:</label>
        <textarea id="modal-descripcion" name="descripcion" class="form-control" rows="4" required></textarea>
      </div>
      <div class="text-center mt-3">
        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
      </div>
    </form>
  </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
// Modal de edición
const editarModal = document.getElementById('editarModal');

// Abrir modal y cargar datos
document.querySelectorAll('.btn-edit').forEach(button => {
  button.addEventListener('click', () => {
    document.getElementById('modal-id').value = button.dataset.id;
    document.getElementById('modal-descripcion').value = button.dataset.descripcion;
    editarModal.style.display = 'flex';
  });
});

// Cerrar modal
document.getElementById('closeEditarModal').addEventListener('click', () => {
  editarModal.style.display = 'none';
});

// Confirmación de eliminación
function confirmarEliminar(event, url) {
  event.preventDefault();
  if (confirm('¿Estás seguro de eliminar este indicador?')) {
    window.location.href = url;
  }
  return false;
}

// Cerrar modal al hacer clic fuera
window.addEventListener('click', (e) => {
  if (e.target === editarModal) {
    editarModal.style.display = 'none';
  }
});

// Ocultar mensajes después de 3 segundos
setTimeout(() => {
  const alerta = document.getElementById('alerta-mensaje');
  if (alerta) {
    alerta.style.opacity = 0;
    setTimeout(() => alerta.remove(), 500);
  }
}, 3000);
</script>
