<div class="dropdown-menu dropdown-menu-right pt-0" aria-labelledby="dd-user-menu">

    <h5 class="p-2 text-center bg-primary">
        <?php echo htmlspecialchars($_SESSION['nombre'] . " " . $_SESSION['apellido']); ?>
    </h5>

    <div class="px-3 py-2" style="color: black; background-color: #f8f9fa;">
        <p class="mb-1"><strong>Nombre:</strong> <?php echo htmlspecialchars($_SESSION['nombre']); ?></p>
        <p class="mb-1"><strong>Apellido:</strong> <?php echo htmlspecialchars($_SESSION['apellido']); ?></p>
        <p class="mb-0"><strong>Usuario:</strong> <?php echo htmlspecialchars($_SESSION['usuario']); ?></p>
    </div>

    <a class="dropdown-item" href="perfil.php"><span class="font-icon glyphicon glyphicon-user"></span> Perfil</a>
    <a class="dropdown-item" href="#"><span class="font-icon glyphicon glyphicon-lock"></span> Cambiar contraseña</a>

    <div class="dropdown-divider"></div>
    <a class="dropdown-item" href="../../controlador/controlador_cerrar_sesion.php">
        <span class="font-icon glyphicon glyphicon-log-out"></span> Salir
    </a>
</div>
