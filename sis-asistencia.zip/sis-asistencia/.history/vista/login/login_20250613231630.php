<?php
include "../../modelo/conexion.php"; // conexión DB

date_default_timezone_set('America/Asuncion'); // Ajusta zona horaria a la tuya

$mensaje = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dni = trim($_POST['dni']);
    $accion = $_POST['accion']; // "entrada" o "salida"
    $hora_actual = date("H:i:s");
    $fecha_actual = date("Y-m-d");

    if (!empty($dni)) {
        // Primero verificamos si ya existe un registro para este DNI y fecha (asistencia del día)
        $sql = "SELECT * FROM asistencia WHERE dni = ? AND fecha = ?";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("ss", $dni, $fecha_actual);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            // Registro existe, actualizamos entrada o salida según botón
            $row = $resultado->fetch_assoc();

            if ($accion == "entrada" && empty($row['hora_entrada'])) {
                $sql_update = "UPDATE asistencia SET hora_entrada = ? WHERE id = ?";
                $stmt_update = $conexion->prepare($sql_update);
                $stmt_update->bind_param("si", $hora_actual, $row['id']);
                $stmt_update->execute();
                $mensaje = "Hora de entrada registrada correctamente.";
            } elseif ($accion == "salida" && empty($row['hora_salida'])) {
                $sql_update = "UPDATE asistencia SET hora_salida = ? WHERE id = ?";
                $stmt_update = $conexion->prepare($sql_update);
                $stmt_update->bind_param("si", $hora_actual, $row['id']);
                $stmt_update->execute();
                $mensaje = "Hora de salida registrada correctamente.";
            } else {
                $mensaje = "Ya está registrada la hora para esta acción.";
            }

        } else {
            // No hay registro para hoy, insertamos nuevo con hora entrada o salida
            if ($accion == "entrada") {
                $sql_insert = "INSERT INTO asistencia (dni, fecha, hora_entrada) VALUES (?, ?, ?)";
                $stmt_insert = $conexion->prepare($sql_insert);
                $stmt_insert->bind_param("sss", $dni, $fecha_actual, $hora_actual);
                $stmt_insert->execute();
                $mensaje = "Hora de entrada registrada correctamente.";
            } elseif ($accion == "salida") {
                $sql_insert = "INSERT INTO asistencia (dni, fecha, hora_salida) VALUES (?, ?, ?)";
                $stmt_insert = $conexion->prepare($sql_insert);
                $stmt_insert->bind_param("sss", $dni, $fecha_actual, $hora_actual);
                $stmt_insert->execute();
                $mensaje = "Hora de salida registrada correctamente.";
            }
        }
    } else {
        $mensaje = "Por favor ingrese un DNI válido.";
    }
}

// Consultamos los registros para mostrar en tabla
$resultado_tabla = $conexion->query("SELECT * FROM asistencia ORDER BY fecha DESC, id DESC");

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Registro de Asistencia</title>
    <link rel="stylesheet" href="css/bootstrap.css" />
</head>
<body class="container py-4">

    <h2>Registro de Asistencia</h2>

    <?php if($mensaje): ?>
        <div class="alert alert-info"><?= htmlspecialchars($mensaje) ?></div>
    <?php endif; ?>

    <form method="POST" class="mb-3">
        <div class="form-group">
            <label for="dni">DNI del Empleado</label>
            <input type="text" name="dni" id="dni" class="form-control" required />
        </div>

        <button type="submit" name="accion" value="entrada" class="btn btn-success">Marcar Entrada</button>
        <button type="submit" name="accion" value="salida" class="btn btn-danger">Marcar Salida</button>
    </form>

    <h3>Asistencias Registradas</h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>DNI</th>
                <th>Fecha</th>
                <th>Hora Entrada</th>
                <th>Hora Salida</th>
            </tr>
        </thead>
        <tbody>
            <?php while($fila = $resultado_tabla->fetch_assoc()): ?>
            <tr>
                <td><?= $fila['id'] ?></td>
                <td><?= htmlspecialchars($fila['dni']) ?></td>
                <td><?= $fila['fecha'] ?></td>
                <td><?= $fila['hora_entrada'] ?? '-' ?></td>
                <td><?= $fila['hora_salida'] ?? '-' ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</body>
</html>
