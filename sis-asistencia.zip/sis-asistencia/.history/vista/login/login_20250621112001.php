<?php
require_once('../../modelo/conexion.php');
session_start();
// tu lógica de login aquí...


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $usuario = trim($_POST["usuario"]);
    $password = trim($_POST["password"]);

    // Verificar si el usuario existe
    $stmt = $conexion->prepare("SELECT * FROM usuario WHERE usuario = ?");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows == 1) {
        $usuario_data = $resultado->fetch_assoc();

        // Verificamos la contraseña
        if (password_verify($password, $usuario_data["password"])) {
            // Autenticación exitosa
            $_SESSION["id_usuario"] = $usuario_data["id_usuario"];
            $_SESSION["nombre"] = $usuario_data["nombre"];
            $_SESSION["apellido"] = $usuario_data["apellido"];
            $_SESSION["usuario"] = $usuario_data["usuario"];

            header("Location: ../vista/inicio.php");
            exit();
        } else {
            $error = "Contraseña incorrecta.";
        }
    } else {
        $error = "El usuario no existe.";
    }

    $stmt->close();
    $conexion->close();
}
?>

<!-- HTML del formulario de login -->
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Iniciar Sesión</title>
  <link rel="stylesheet" href="../public/bootstrap5/css/bootstrap.min.css">
</head>
<body class="d-flex justify-content-center align-items-center" style="height: 100vh;">
  <div class="card p-4" style="width: 350px;">
    <h4 class="text-center mb-4">Iniciar Sesión</h4>
    
    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="mb-3">
        <input type="text" name="usuario" class="form-control" placeholder="Usuario" required>
      </div>
      <div class="mb-3">
        <input type="password" name="password" class="form-control" placeholder="Contraseña" required>
      </div>
      <button type="submit" class="btn btn-primary w-100">Ingresar</button>
    </form>
  </div>
</body>
</html>
