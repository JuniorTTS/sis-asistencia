<?php
require('../modelo/conexion.php'); // Ajusta la ruta si es necesario

// Incluimos la librería FPDF
require('../librerias/fpdf/fpdf.php');

// Consulta a la base de datos
$sql = $conexion->query("SELECT
    asistencia.id_asistencia, 
    empleado.nombre as nom_docente, 
    empleado.apellido, 
    empleado.dni, 
    cargo.nombre as nom_especialidad,
    asistencia.entrada, 
    asistencia.salida
FROM
    asistencia
    INNER JOIN empleado ON asistencia.id_empleado = empleado.id_empleado
    INNER JOIN cargo ON empleado.cargo = cargo.id_cargo");

// Crear el PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,10,'Informe de Asistencia del Personal',0,1,'C');
$pdf->Ln(5);

// Encabezado de la tabla
$pdf->SetFont('Arial','B',10);
$pdf->Cell(10,10,'ID',1);
$pdf->Cell(40,10,'Personal',1);
$pdf->Cell(25,10,'DNI',1);
$pdf->Cell(40,10,'Especialidad',1);
$pdf->Cell(35,10,'Entrada',1);
$pdf->Cell(35,10,'Salida',1);
$pdf->Ln();

// Datos de la tabla
$pdf->SetFont('Arial','',10);
while($row = $sql->fetch_object()){
    $pdf->Cell(10,10, $row->id_asistencia,1);
    $pdf->Cell(40,10, utf8_decode($row->nom_docente . ' ' . $row->apellido),1);
    $pdf->Cell(25,10, $row->dni,1);
    $pdf->Cell(40,10, utf8_decode($row->nom_especialidad),1);
    $pdf->Cell(35,10, $row->entrada,1);
    $pdf->Cell(35,10, $row->salida,1);
    $pdf->Ln();
}

$pdf->Output();
?>
