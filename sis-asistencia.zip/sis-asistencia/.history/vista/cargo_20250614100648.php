<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
?>

<div class="page-content">
    <h4 class="text-center texte-secondary">LISTA DE CARGOS</h4>

    <?php if (isset($_GET['mensaje'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
    <?php elseif (isset($_GET['error'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
    <?php endif; ?>

    <a href="registro_cargo.php" class="btn btn-primary btn-rounded mb-2">
        <i class="fa-solid fa-plus"></i> Registrar
    </a>

    <table class="table table-bordered table-hover col-md-12" id="example">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre del Cargo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = $conexion->query("SELECT * FROM cargo ORDER BY nombre ASC");
            while ($datos = $sql->fetch_object()):
            ?>
                <tr>
                    <td><?= $datos->id_cargo ?></td>
                    <td><?= htmlspecialchars($datos->nombre) ?></td>
                    <td>
                        <!-- Botón modificar con data atributos para modal -->
                        <button type="button" class="btn btn-warning btn-modificar" 
                                data-id="<?= $datos->id_cargo ?>" 
                                data-nombre="<?= htmlspecialchars($datos->nombre) ?>">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </button>

                        <!-- Enlace eliminar -->
                        <a href="../controlador/controlador_eliminar_cargo.php?id=<?= $datos->id_cargo ?>"
                           onclick="return confirm('¿Está seguro de eliminar este cargo?');"
                           class="btn btn-danger">
                            <i class="fa-regular fa-trash-can"></i>
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- Modal para modificar cargo (igual que en usuario/empleado) -->
<div class="modal fade" id="modalModificarCargo" tabindex="-1" aria-labelledby="modalModificarCargoLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="actualizar_cargo.php" method="POST" id="formModificarCargo">
        <div class="modal-header">
          <h5 class="modal-title" id="modalModificarCargoLabel">Modificar Cargo</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
            <input type="hidden" name="id_cargo" id="idCargoModificar">
            <div class="mb-3">
                <label for="nombreCargoModificar" class="form-label">Nombre del Cargo</label>
                <input type="text" name="nombre" id="nombreCargoModificar" class="form-control" required>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
    // Esperar que la página cargue
    document.addEventListener('DOMContentLoaded', function() {
        var modalModificar = new bootstrap.Modal(document.getElementById('modalModificarCargo'));

        // Seleccionamos todos los botones modificar
        document.querySelectorAll('.btn-modificar').forEach(function(button) {
            button.addEventListener('click', function() {
                // Cargar datos en el modal
                document.getElementById('idCargoModificar').value = this.dataset.id;
                document.getElementById('nombreCargoModificar').value = this.dataset.nombre;

                // Abrir modal
                modalModificar.show();
            });
        });
    });
</script>
