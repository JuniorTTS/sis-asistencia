<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_cargo = intval($_POST['id_cargo']);
    $nombre = trim($_POST['nombre']);

    if ($id_cargo > 0 && !empty($nombre)) {
        $update = $conexion->prepare("UPDATE cargo SET nombre=? WHERE id_cargo=?");
        $update->bind_param("si", $nombre, $id_cargo);

        if ($update->execute()) {
            header("Location: cargo.php?mensaje=Cargo actualizado correctamente");
            exit();
        } else {
            header("Location: cargo.php?error=Error al actualizar el cargo");
            exit();
        }
    } else {
        header("Location: cargo.php?error=Datos inválidos");
        exit();
    }
} else {
    header("Location: cargo.php");
    exit();
}
