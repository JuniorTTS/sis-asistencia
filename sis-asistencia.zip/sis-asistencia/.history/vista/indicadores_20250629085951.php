<?php
session_start();
if (empty($_SESSION['id_usuario']) || empty($_SESSION['nombre']) || empty($_SESSION['apellido'])) {
    header('location:../login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
?>

<style>
  ul li:nth-child(5) .activo {
    background: rgb(11, 150, 214) !important;
  }

  .modal-custom {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }

  .modal-content-custom {
    background: #fff;
    padding: 30px 20px;
    width: 400px;
    border-radius: 12px;
    position: relative;
    box-shadow: 0 8px 16px rgba(0,0,0,0.2);
    animation: fadeIn 0.3s ease-in-out;
  }

  .close-custom {
    position: absolute;
    right: 15px;
    top: 10px;
    font-size: 24px;
    cursor: pointer;
    color: #999;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: scale(0.95); }
    to { opacity: 1; transform: scale(1); }
  }
</style>

<div class="page-content">
  <h4 class="text-center texte-secondary">INDICADORES</h4>

  <?php if (isset($_GET['mensaje'])): ?>
    <div id="alerta-mensaje" class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
  <?php elseif (isset($_GET['error'])): ?>
    <div id="alerta-mensaje" class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
  <?php endif; ?>

  <table class="table table-bordered table-hover col-md-12" id="example">
    <thead>
      <tr>
        <th>ID</th>
        <th>Descripción</th>
        <th>Fecha</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $id_usuario = $_SESSION['id_usuario'];
      $sql = $conexion->prepare("SELECT * FROM indicadores WHERE id_usuario = ? ORDER BY fecha DESC");
      $sql->bind_param("i", $id_usuario);
      $sql->execute();
      $resultado = $sql->get_result();
      while ($datos = $resultado->fetch_object()):
      ?>
        <tr>
          <td><?= $datos->id_indicador ?></td>
          <td><?= htmlspecialchars($datos->descripcion) ?></td>
          <td><?= htmlspecialchars($datos->fecha) ?></td>
          <td>
            <button class="btn btn-warning btn-edit" 
                    data-id="<?= $datos->id_indicador ?>" 
                    data-descripcion="<?= htmlspecialchars($datos->descripcion) ?>">
              <i class="fa-solid fa-pen"></i>
            </button>

            <a href="../controlador/controlador_eliminar_indicador.php?id=<?= $datos->id_indicador ?>"
               onclick="confirmarEliminar(event, this.href)" 
               class="btn btn-danger">
              <i class="fa-regular fa-trash-can"></i>
            </a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- Modal de editar -->
<div id="editarModal" class="modal-custom" tabindex="-1" role="dialog" aria-modal="true" aria-labelledby="editarModalLabel">
  <div class="modal-content-custom">
    <button type="button" class="close-custom" aria-label="Cerrar" id="closeEditarModal">&times;</button>
    <form action="../controlador/actualizar_indicador.php" method="POST">
      <input type="hidden" id="modal-id" name="id_indicador">
      <div class="form-group">
        <label for="modal-descripcion">Descripción</label>
        <textarea id="modal-descripcion" name="descripcion" class="form-control" required></textarea>
      </div>
      <button type="submit" class="btn btn-primary mt-2">Guardar Cambios</button>
    </form>
  </div>
</div>

<!-- Modal de Confirmación de Eliminación -->
<div id="confirmarEliminarModal" class="modal-custom" tabindex="-1" role="dialog" aria-modal="true" aria-labelledby="confirmarEliminarLabel">
  <div class="modal-content-custom text-center">
    <button type="button" class="close-custom" aria-label="Cerrar" id="closeConfirmModal">&times;</button>
    <h5 id="confirmarEliminarLabel" class="mb-3">Confirmar Eliminación</h5>
    <p>¿Estás seguro de que deseas eliminar este indicador?</p>
    <div class="d-flex justify-content-center mt-4">
      <button id="cancelarEliminar" class="btn btn-secondary mx-2">Cancelar</button>
      <button id="confirmarEliminarBtn" class="btn btn-danger mx-2">Eliminar</button>
    </div>
  </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
const editarModal = document.getElementById('editarModal');
const confirmarEliminarModal = document.getElementById('confirmarEliminarModal');
let eliminarUrl = "";

document.querySelectorAll('.btn-edit').forEach(button => {
  button.addEventListener('click', () => {
    document.getElementById('modal-id').value = button.dataset.id;
    document.getElementById('modal-descripcion').value = button.dataset.descripcion;
    editarModal.style.display = 'flex';
  });
});

document.getElementById('closeEditarModal').addEventListener('click', () => {
  editarModal.style.display = 'none';
});

document.getElementById('closeConfirmModal').addEventListener('click', () => {
  confirmarEliminarModal.style.display = 'none';
});

document.getElementById('cancelarEliminar').addEventListener('click', () => {
  confirmarEliminarModal.style.display = 'none';
});

function confirmarEliminar(event, url) {
  event.preventDefault();
  eliminarUrl = url;
  confirmarEliminarModal.style.display = 'flex';
}

document.getElementById('confirmarEliminarBtn').addEventListener('click', () => {
  window.location.href = eliminarUrl;
});

window.addEventListener('click', (e) => {
  if (e.target === editarModal) {
    editarModal.style.display = 'none';
  }
  if (e.target === confirmarEliminarModal) {
    confirmarEliminarModal.style.display = 'none';
  }
});

setTimeout(() => {
  const alerta = document.getElementById('alerta-mensaje');
  if (alerta) {
    alerta.style.transition = "opacity 0.5s ease";
    alerta.style.opacity = 0;
    setTimeout(() => {
      alerta.remove();
    }, 500);
  }

  if (window.history.replaceState) {
    const url = new URL(window.location);
    url.searchParams.delete('mensaje');
    url.searchParams.delete('error');
    window.history.replaceState({}, document.title, url.pathname);
  }
}, 3000);
</script>