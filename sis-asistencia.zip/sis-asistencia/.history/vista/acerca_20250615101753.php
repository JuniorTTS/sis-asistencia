<?php require('./layout/topbar.php'); ?>
<?php require('./layout/sidebar.php'); ?>
<?php
require_once "../modelo/conexion.php";

$mensaje = $_SESSION['mensaje'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['mensaje'], $_SESSION['error']);

// Consultar datos de la empresa
$resultado = $conexion->query("SELECT * FROM empresa LIMIT 1");
$empresa = $resultado->fetch_object();
?>

<style>
  .modal-custom {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }

  .modal-content-custom {
    background: #fff;
    padding: 30px 20px;
    width: 450px;
    border-radius: 12px;
    position: relative;
    box-shadow: 0 8px 16px rgba(0,0,0,0.3);
    animation: fadeIn 0.3s ease-in-out;
  }

  .close-custom {
    position: absolute;
    right: 15px;
    top: 10px;
    font-size: 24px;
    cursor: pointer;
    color: #999;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: scale(0.95); }
    to { opacity: 1; transform: scale(1); }
  }
</style>

<div class="page-content">
    <h3 class="text-center text-secondary mb-4">Información de la Empresa</h3>

    <?php if ($mensaje): ?>
      <div id="alerta-mensaje" class="alert alert-success text-center"><?= htmlspecialchars($mensaje) ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div id="alerta-mensaje" class="alert alert-danger text-center"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card mx-auto shadow" style="max-width: 90%; padding: 40px; font-size: 1.3rem;">
        <div class="card-body text-center">
            <h2 class="card-title mb-4"><i class="fa-solid fa-building fa-lg"></i> <?= htmlspecialchars($empresa->nombre) ?></h2>

            <p class="card-text mb-3">
                <i class="fa-solid fa-phone fa-lg"></i> 
                <strong>Teléfono:</strong> <?= htmlspecialchars($empresa->telefono) ?>
            </p>

            <p class="card-text mb-3">
                <i class="fa-solid fa-location-dot fa-lg"></i> 
                <strong>Ubicación:</strong> 
                <a href="https://www.google.com/maps/search/?api=1&query=<?= urlencode($empresa->ubicacion) ?>" target="_blank" style="text-decoration:none; color:#0d6efd;">
                    <?= htmlspecialchars($empresa->ubicacion) ?>
                </a>
            </p>

            <p class="card-text mb-4">
                <i class="fa-solid fa-envelope fa-lg"></i> 
                <strong>Correo:</strong> 
                <a href="mailto:<?= htmlspecialchars($empresa->correo) ?>" style="text-decoration:none; color:#0d6efd;">
                    <?= htmlspecialchars($empresa->correo) ?>
                </a>
            </p>

            <button class="btn btn-primary btn-edit mt-3">
                <i class="fa-solid fa-pen-to-square"></i> Modificar Datos
            </button>
        </div>
    </div>
</div>

<!-- Modal para editar empresa -->
<div id="editarEmpresaModal" class="modal-custom">
    <div class="modal-content-custom">
        <button type="button" class="close-custom" id="closeEditarEmpresaModal">&times;</button>
        <form id="empresaForm" action="actualizar_empresa.php" method="POST">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre:</label>
                <input type="text" name="nombre" id="nombre" class="form-control" value="<?= htmlspecialchars($empresa->nombre) ?>" required>
            </div>
            <div class="mb-3">
                <label for="telefono" class="form-label">Teléfono:</label>
                <input type="text" name="telefono" id="telefono" class="form-control" value="<?= htmlspecialchars($empresa->telefono) ?>" required>
            </div>
            <div class="mb-3">
                <label for="ubicacion" class="form-label">Ubicación:</label>
                <input type="text" name="ubicacion" id="ubicacion" class="form-control" value="<?= htmlspecialchars($empresa->ubicacion) ?>" required>
            </div>
            <div class="mb-3">
                <label for="correo" class="form-label">Correo:</label>
                <input type="email" name="correo" id="correo" class="form-control" value="<?= htmlspecialchars($empresa->correo) ?>" required>
            </div>
            <button type="submit" class="btn btn-success w-100">Guardar Cambios</button>
        </form>
    </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
// Mostrar modal
document.querySelector('.btn-edit').addEventListener('click', () => {
    document.getElementById('editarEmpresaModal').style.display = 'flex';
});

// Cerrar modal
document.getElementById('closeEditarEmpresaModal').addEventListener('click', () => {
    document.getElementById('editarEmpresaModal').style.display = 'none';
});

// Cerrar si se hace clic fuera del contenido
window.addEventListener('click', (e) => {
    const modal = document.getElementById('editarEmpresaModal');
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});

// Validación básica antes de enviar
document.getElementById('empresaForm').addEventListener('submit', function(e) {
    const correo = document.getElementById('correo').value;
    const regexCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!regexCorreo.test(correo)) {
        e.preventDefault();
        alert('Por favor, ingrese un correo electrónico válido.');
    }
});

// Ocultar mensajes luego de 3 segundos
setTimeout(() => {
    const alerta = document.getElementById('alerta-mensaje');
    if (alerta) {
        alerta.style.transition = "opacity 0.5s ease";
        alerta.style.opacity = 0;
        setTimeout(() => alerta.remove(), 500);
    }
}, 3000);
</script>
