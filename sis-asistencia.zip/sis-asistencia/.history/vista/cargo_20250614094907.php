<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
require_once "../controlador/controlador_eliminar_cargo.php";
?>

<div class="page-content">
    <h4 class="text-center texte-secondary">LISTA DE CARGOS</h4>

    <?php if (isset($_GET['mensaje'])): ?>
        <div id="alerta-mensaje" class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
    <?php elseif (isset($_GET['error'])): ?>
        <div id="alerta-mensaje" class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
    <?php endif; ?>

    <a href="registro_cargo.php" class="btn btn-primary btn-rounded mb-2">
        <i class="fa-solid fa-plus"></i> Registrar Cargo
    </a>

    <table class="table table-bordered table-hover col-md-12" id="example">
        <thead>
            <tr>
                <th>ID</th>
                <th>NOMBRE DEL CARGO</th>
                <th>ACCIONES</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = $conexion->query("SELECT id_cargo, nombre FROM cargo");
            while ($datos = $sql->fetch_object()):
            ?>
                <tr>
                    <td><?= $datos->id_cargo ?></td>
                    <td><?= htmlspecialchars($datos->nombre) ?></td>
                    <td>
                        <a href="actualizar_cargo.php?id=<?= $datos->id_cargo ?>" class="btn btn-warning">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </a>
                        <a href="../controlador/controlador_eliminar_cargo.php?id=<?= $datos->id_cargo ?>"
                           onclick="return confirm('¿Estás seguro que deseas eliminar este cargo?')"
                           class="btn btn-danger">
                           <i class="fa-solid fa-trash"></i>
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php require('./layout/footer.php'); ?>
