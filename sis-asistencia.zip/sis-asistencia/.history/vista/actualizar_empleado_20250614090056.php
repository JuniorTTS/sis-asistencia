<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_empleado = $_POST['id_empleado'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $dni = $_POST['dni'];
    $cargo = $_POST['cargo'];

    $update = $conexion->prepare("UPDATE empleado SET nombre=?, apellido=?, dni=?, cargo=? WHERE id_empleado=?");
    $update->bind_param("ssssi", $nombre, $apellido, $dni, $cargo, $id_empleado);

    if ($update->execute()) {
        header("Location: empleado.php?mensaje=Empleado actualizado correctamente");
    } else {
        header("Location: empleado.php?error=Error al actualizar el empleado");
    }
    exit();
}
?>
