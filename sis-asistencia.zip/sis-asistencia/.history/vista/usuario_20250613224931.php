<a href="#" data-toggle="modal" data-target="#editarModal<?= $datos->id_usuario ?>" class="btn btn-warning btn-sb">
  <i class="fa-solid fa-user-pen"></i>
</a>

<!-- Modal -->
<div class="modal fade" id="editarModal<?= $datos->id_usuario ?>" tabindex="-1" role="dialog" aria-labelledby="modalLabel<?= $datos->id_usuario ?>" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="actualizar_usuario.php" method="POST">
        <div class="modal-header">
          <h5 class="modal-title" id="modalLabel<?= $datos->id_usuario ?>">Editar Usuario</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body">
          <input type="hidden" name="id_usuario" value="<?= $datos->id_usuario ?>">
          <div class="form-group">
            <label>Nombre</label>
            <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($datos->nombre) ?>" required>
          </div>
          <div class="form-group">
            <label>Apellido</label>
            <input type="text" name="apellido" class="form-control" value="<?= htmlspecialchars($datos->apellido) ?>" required>
          </div>
          <div class="form-group">
            <label>Usuario</label>
            <input type="text" name="usuario" class="form-control" value="<?= htmlspecialchars($datos->usuario) ?>" required>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
          <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
