<?php
require_once "../modelo/conexion.php";

$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$ubicacion = $_POST['ubicacion'];
$correo = $_POST['correo'];

$stmt = $conexion->prepare("UPDATE empresa SET nombre=?, telefono=?, ubicacion=?, correo=? LIMIT 1");
$stmt->bind_param("ssss", $nombre, $telefono, $ubicacion, $correo);

if ($stmt->execute()) {
    header("Location: acerca.php?mensaje=Datos actualizados correctamente");
    exit();
} else {
    header("Location: acerca.php?mensaje=Error al actualizar");
    exit();
}
?>
