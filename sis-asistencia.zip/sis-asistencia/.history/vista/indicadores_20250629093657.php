<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
?>

<style>
  ul li:nth-child(5) .activo {
    background: rgb(11, 150, 214) !important;
  }

  /* Estilos para ambos modales */
  .modal-custom {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    opacity: 0;
    transition: opacity 0.3s ease;
  }

  .modal-custom.active {
    display: flex;
    opacity: 1;
  }

  .modal-content-custom {
    background: #fff;
    padding: 30px 20px;
    width: 400px;
    border-radius: 12px;
    position: relative;
    box-shadow: 0 8px 16px rgba(0,0,0,0.2);
    transform: scale(0.95);
    transition: transform 0.3s ease, opacity 0.3s ease;
    opacity: 0;
  }

  .modal-custom.active .modal-content-custom {
    transform: scale(1);
    opacity: 1;
  }

  .close-custom {
    position: absolute;
    right: 15px;
    top: 10px;
    font-size: 24px;
    cursor: pointer;
    color: #999;
    transition: color 0.2s;
  }

  .close-custom:hover {
    color: #666;
  }

  /* Estilos específicos para el modal de edición */
  .modal-textarea {
    width: 100%;
    min-height: 100px;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    resize: vertical;
    transition: border-color 0.3s;
  }

  .modal-textarea:focus {
    border-color: #4285f4;
    outline: none;
  }

  /* Estilos específicos para el modal de confirmación */
  .confirm-modal-content {
    text-align: center;
    padding: 25px;
  }

  .confirm-icon {
    font-size: 48px;
    color: #f44336;
    margin-bottom: 20px;
  }

  .confirm-buttons {
    display: flex;
    justify-content: center;
    gap: 15px;
    margin-top: 25px;
  }

  .btn-cancel {
    background-color: #6c757d;
    border-color: #6c757d;
  }

  .btn-confirm {
    background-color: #dc3545;
    border-color: #dc3545;
  }
</style>

<div class="page-content">
  <h4 class="text-center texte-secondary">INDICADORES</h4>

  <?php if (isset($_GET['mensaje'])): ?>
    <div id="alerta-mensaje" class="alert alert-success"><?= htmlspecialchars($_GET['mensaje']) ?></div>
  <?php elseif (isset($_GET['error'])): ?>
    <div id="alerta-mensaje" class="alert alert-danger"><?= htmlspecialchars($_GET['error']) ?></div>
  <?php endif; ?>

  <table class="table table-bordered table-hover col-md-12" id="example">
    <thead>
      <tr>
        <th>ID</th>
        <th>USUARIO</th>
        <th>DESCRIPCIÓN</th>
        <th>FECHA</th>
        <th>ACCIONES</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = $conexion->query("SELECT
        indicadores.id_indicador,
        empleado.nombre AS nombre_usuario,
        indicadores.descripcion,
        DATE_FORMAT(indicadores.fecha, '%d/%m/%Y %H:%i') as fecha_formateada
      FROM
        indicadores
        INNER JOIN empleado ON indicadores.id_usuario = empleado.id_empleado");
      while ($datos = $sql->fetch_object()):
      ?>
        <tr>
          <td><?= $datos->id_indicador ?></td>
          <td><?= htmlspecialchars($datos->nombre_usuario) ?></td>
          <td><?= htmlspecialchars($datos->descripcion) ?></td>
          <td><?= htmlspecialchars($datos->fecha_formateada) ?></td>
          <td>
            <button class="btn btn-warning btn-sm btn-edit" 
                    data-id="<?= $datos->id_indicador ?>" 
                    data-descripcion="<?= htmlspecialchars($datos->descripcion) ?>">
              <i class="fa-solid fa-user-pen"></i> 
            </button>

            <button class="btn btn-danger btn-sm btn-delete" 
                    data-id="<?= $datos->id_indicador ?>">
              <i class="fa-regular fa-trash-can"></i> 
            </button>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- Modal de editar -->
<div id="editarModal" class="modal-custom">
  <div class="modal-content-custom">
    <span class="close-custom" id="closeEditarModal">&times;</span>
    <h4 class="text-center mb-3">Modificar Descripción</h4>
    <form action="../controlador/controlador_actualizar_indicador.php" method="POST">
      <input type="hidden" id="modal-id" name="id_indicador">
      <div class="form-group">
        <textarea id="modal-descripcion" name="descripcion" class="modal-textarea" required></textarea>
      </div>
      <div class="text-center mt-3">
        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal de Confirmación de Eliminación - Versión profesional -->
<div id="confirmarEliminarModal" class="modal-custom">
  <div class="modal-content-custom confirm-modal-content">
    <span class="close-custom" id="closeConfirmModal">&times;</span>
    <div class="confirm-icon">
      <i class="fas fa-exclamation-triangle"></i>
    </div>
    <h4>¿Confirmar eliminación?</h4>
    <p>Esta acción eliminará permanentemente el indicador seleccionado.</p>
    <p class="text-muted">Esta operación no se puede deshacer.</p>
    
    <div class="confirm-buttons">
      <button id="cancelarEliminar" class="btn btn-cancel btn-secondary">
        <i class="fas fa-times"></i> Cancelar
      </button>
      <button id="confirmarEliminarBtn" class="btn btn-confirm btn-danger">
        <i class="fas fa-check"></i> Confirmar
      </button>
    </div>
  </div>
</div>

<?php require('./layout/footer.php'); ?>

<script>
// Variables globales
let currentDeleteId = null;

// Modal de edición
const editarModal = document.getElementById('editarModal');
const abrirModalEdicion = (id, descripcion) => {
    document.getElementById('modal-id').value = id;
    document.getElementById('modal-descripcion').value = descripcion;
    editarModal.classList.add('active');
};

// Modal de confirmación de eliminación
const confirmarModal = document.getElementById('confirmarEliminarModal');
const abrirModalEliminar = (id) => {
    currentDeleteId = id;
    confirmarModal.classList.add('active');
};

// Cerrar modales
const cerrarModales = () => {
    editarModal.classList.remove('active');
    confirmarModal.classList.remove('active');
};

// Event Listeners
document.querySelectorAll('.btn-edit').forEach(btn => {
    btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        const descripcion = btn.getAttribute('data-descripcion');
        abrirModalEdicion(id, descripcion);
    });
});

document.querySelectorAll('.btn-delete').forEach(btn => {
    btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        abrirModalEliminar(id);
    });
});

document.getElementById('closeEditarModal').addEventListener('click', cerrarModales);
document.getElementById('closeConfirmModal').addEventListener('click', cerrarModales);
document.getElementById('cancelarEliminar').addEventListener('click', cerrarModales);

// Confirmar eliminación
document.getElementById('confirmarEliminarBtn').addEventListener('click', () => {
    if (currentDeleteId) {
        window.location.href = `../controlador/controlador_eliminar_indicador.php?id=${currentDeleteId}`;
    }
});

// Cerrar al hacer clic fuera del modal
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal-custom')) {
        cerrarModales();
    }
});

// Ocultar mensajes después de 3 segundos
setTimeout(() => {
    const alerta = document.getElementById('alerta-mensaje');
    if (alerta) {
        alerta.style.transition = "opacity 0.5s";
        alerta.style.opacity = '0';
        setTimeout(() => alerta.remove(), 500);
    }
}, 3000);
</script>
