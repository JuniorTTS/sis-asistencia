<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";
require_once "../controlador/controlador_eliminar_asistencia.php";
?>

<style>
  ul li:nth-child(1) .activo {
    background: rgb(11, 150, 214) !important;
  }

  .modal-custom {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    display: flex; /* importante para centrar */
    align-items: center;
    justify-content: center;
    z-index: 9999;
    display: none; /* oculto por defecto, jQuery fadeIn lo muestra */
  }

  .modal-content-custom {
    background: #fff;
    padding: 30px 20px;
    width: 400px;
    border-radius: 12px;
    position: relative;
    box-shadow: 0 8px 16px rgba(0,0,0,0.2);
    animation: fadeIn 0.3s ease-in-out;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }

  .close-custom {
    position: absolute;
    right: 15px;
    top: 10px;
    font-size: 24px;
    cursor: pointer;
    color: #999;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: scale(0.95); }
    to { opacity: 1; transform: scale(1); }
  }
</style>

<div class="page-content">
  <h4 class="text-center texte-secondary">ASISTENCIA DEL PERSONAL</h4>

  <div class="mb-3">
    <a href="generar_reporte.php" target="_blank" class="btn btn-danger">
      <i class="fa-solid fa-file-pdf"></i> Reporte
    </a>
  </div>

  <table class="table table-bordered table-hover col-md-12" id="example">
    <thead>
      <tr>
        <th>ID</th>
        <th>PERSONAL</th>
        <th>DNI</th>
        <th>ESPECIALIDAD</th>
        <th>ENTRADA</th>
        <th>SALIDA</th>
        <th>ACCIONES</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $sql = $conexion->query("SELECT
        asistencia.*, 
        asistencia.id_asistencia, 
        asistencia.id_empleado, 
        asistencia.entrada, 
        asistencia.salida, 
        empleado.*, 
        empleado.id_empleado, 
        empleado.nombre as 'nom_docente', 
        empleado.cargo, 
        empleado.dni, 
        empleado.apellido, 
        cargo.*, 
        cargo.id_cargo, 
        cargo.nombre as 'nom_especialidad'
      FROM
        asistencia
        INNER JOIN empleado ON asistencia.id_empleado = empleado.id_empleado
        INNER JOIN cargo ON empleado.cargo = cargo.id_cargo");

      while ($datos = $sql->fetch_object()):
      ?>
        <tr>
          <td><?= $datos->id_asistencia ?></td>
          <td><?= htmlspecialchars($datos->nom_docente . " " . $datos->apellido) ?></td>
          <td><?= htmlspecialchars($datos->dni) ?></td>
          <td><?= htmlspecialchars($datos->nom_especialidad) ?></td>
          <td><?= htmlspecialchars($datos->entrada) ?></td>
          <td><?= htmlspecialchars($datos->salida) ?></td>
          <td>
            <button class="btn btn-danger btn-eliminar" data-id="<?= $datos->id_asistencia ?>">
              <i class="fa-regular fa-trash-can"></i>
            </button>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<!-- Modal de Confirmación -->
<div id="confirmarEliminarModal" class="modal-custom">
  <div class="modal-content-custom text-center">
    <span class="close-custom" id="closeConfirmModal">&times;</span>
    <h5 class="mb-3">Confirmar Eliminación</h5>
    <p>¿Estás seguro de que deseas eliminar este registro de asistencia?</p>
    <div class="d-flex justify-content-center mt-4">
      <button id="cancelarEliminar" class="btn btn-secondary mx-2">Cancelar</button>
      <a id="confirmarEliminarBtn" class="btn btn-danger mx-2" href="#">Eliminar</a>
    </div>
  </div>
</div>

<?php require('./layout/footer.php'); ?>

<!-- Inicialización DataTable y lógica del modal -->
<script>
$(document).ready(function() {
  if (!$.fn.DataTable.isDataTable('#example')) {
    $('#example').DataTable({
      "language": {
        "lengthMenu": "Mostrar _MENU_ registros por página",
        "zeroRecords": "No se encontraron resultados",
        "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
        "search": "Buscar:",
        "paginate": {
          "first": "Primero",
          "last": "Último",
          "next": "Siguiente",
          "previous": "Anterior"
        }
      },
      "pageLength": 10
    });
  }

  let eliminarID = null;

  $('.btn-eliminar').click(function() {
    eliminarID = $(this).data('id');
    $('#confirmarEliminarModal').fadeIn();
  });

  $('#cancelarEliminar, #closeConfirmModal').click(function() {
    $('#confirmarEliminarModal').fadeOut();
  });

  $('#confirmarEliminarBtn').click(function(e) {
    e.preventDefault();
    if (eliminarID) {
      window.location.href = "inicio.php?id=" + eliminarID;
    }
  });
});
</script>
