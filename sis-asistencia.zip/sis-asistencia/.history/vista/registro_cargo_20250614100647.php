<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require('./layout/topbar.php');
require('./layout/sidebar.php');
require_once "../modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);

    if (!empty($nombre)) {
        $insert = $conexion->prepare("INSERT INTO cargo (nombre) VALUES (?)");
        $insert->bind_param("s", $nombre);

        if ($insert->execute()) {
            header("Location: cargo.php?mensaje=Cargo registrado correctamente");
            exit();
        } else {
            $error = "Error al registrar el cargo";
        }
    } else {
        $error = "Debe ingresar un nombre";
    }
}
?>

<div class="page-content">
    <h4 class="text-center texte-secondary">Registrar Nuevo Cargo</h4>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="registro_cargo.php">
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre del Cargo</label>
            <input type="text" name="nombre" id="nombre" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-success">Registrar</button>
        <a href="cargo.php" class="btn btn-secondary">Volver</a>
    </form>
</div>

<?php require('./layout/footer.php'); ?>
