<?php
session_start();
if (empty($_SESSION['nombre']) && empty($_SESSION['apellido'])) {
    header('location:login/login.php');
    exit();
}

require_once "../modelo/conexion.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validar que existan los datos necesarios
    if (!empty($_POST['nombre']) && !empty($_POST['apellido']) && !empty($_POST['dni']) && !empty($_POST['cargo'])) {
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $dni = $_POST['dni'];
        $cargo = $_POST['cargo'];

        $insert = $conexion->prepare("INSERT INTO empleado (nombre, apellido, dni, cargo) VALUES (?, ?, ?, ?)");
        $insert->bind_param("ssss", $nombre, $apellido, $dni, $cargo);

        if ($insert->execute()) {
            // Redirigir a la lista de empleados con mensaje de éxito
            header("Location: empleado.php?mensaje=Empleado registrado correctamente");
            exit();
        } else {
            // Redirigir a la página de registro con error
            header("Location: registro_empleado.php?error=Error al registrar el empleado");
            exit();
        }
    } else {
        // Redirigir a la página de registro con error por datos faltantes
        header("Location: registro_empleado.php?error=Por favor complete todos los campos");
        exit();
    }
}
?>
